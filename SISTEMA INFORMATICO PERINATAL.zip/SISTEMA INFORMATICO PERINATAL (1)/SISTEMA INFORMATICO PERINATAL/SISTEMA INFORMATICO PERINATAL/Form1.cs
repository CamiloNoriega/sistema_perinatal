﻿namespace SISTEMA_INFORMATICO_PERINATAL
{
    public partial class MENU : Form
    {
        public MENU()
        {
            InitializeComponent();
        }

        private void btnhcperinatal_Click(object sender, EventArgs e)
        {

            HCPERINATAL ven3 = new HCPERINATAL();
            ven3.Show();
            this.Hide();
        }

        private void btnSalirm_Click(object sender, EventArgs e)
        {
            REGISTRO ven1 = new REGISTRO();
            ven1.Show();
            this.Hide();
        }

        private void btnAntecedentes_Click(object sender, EventArgs e)
        {
            ANTECEDENTES ven4 = new ANTECEDENTES();
            ven4.Show();
            this.Hide();
        }

        private void btnEnfermedades_Click(object sender, EventArgs e)
        {
            ENFERMEDADES ven5 = new ENFERMEDADES();
            ven5.Show();
            this.Hide();
        }
    }
}
