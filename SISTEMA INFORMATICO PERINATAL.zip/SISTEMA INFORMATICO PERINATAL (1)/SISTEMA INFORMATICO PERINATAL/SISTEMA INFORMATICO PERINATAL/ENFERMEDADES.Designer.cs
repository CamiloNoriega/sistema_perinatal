﻿namespace SISTEMA_INFORMATICO_PERINATAL
{
    partial class ENFERMEDADES
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ENFERMEDADES));
            gbEnfermedadesPM = new GroupBox();
            gbTDPPRUEBA = new GroupBox();
            gbSifilis = new GroupBox();
            lblSifilis = new Label();
            rbnSifilisneg = new RadioButton();
            rbnSifilispos = new RadioButton();
            rbnSifilisnr = new RadioButton();
            rbnsifilisnc = new RadioButton();
            label32 = new Label();
            gbVIH = new GroupBox();
            lblVIH = new Label();
            rbnVIHnr = new RadioButton();
            rbnVIHnc = new RadioButton();
            rbnVIHposi = new RadioButton();
            rbnVIHneg = new RadioButton();
            label31 = new Label();
            label30 = new Label();
            label29 = new Label();
            gbTARV = new GroupBox();
            rbnTARVnc = new RadioButton();
            rbnTARVn = new RadioButton();
            rbnTARVs = new RadioButton();
            gbEnfermedades = new GroupBox();
            gbOtraCondGrave = new GroupBox();
            rbnotracondN = new RadioButton();
            rbnotracondS = new RadioButton();
            gbHemorragia = new GroupBox();
            gbInfectPuerperal = new GroupBox();
            rbninfectpuerpN = new RadioButton();
            rbninfectpuerpS = new RadioButton();
            txtpostparto = new TextBox();
            lblNo3 = new Label();
            gbPostparto = new GroupBox();
            rbnpostpartoN = new RadioButton();
            rbnpostpartoS = new RadioButton();
            txt3er = new TextBox();
            txtpuerperal = new TextBox();
            gb1erTrim = new GroupBox();
            rbn1ertrimN = new RadioButton();
            rbn1ertrimS = new RadioButton();
            gb2doTrim = new GroupBox();
            rbn2dotrimN = new RadioButton();
            rbn2dotrimS = new RadioButton();
            lbl1erTrim = new Label();
            txt2do = new TextBox();
            gb3erTrim = new GroupBox();
            rbn3ertrimN = new RadioButton();
            rbn3ertrimS = new RadioButton();
            lbl3erTrim = new Label();
            txt1er = new TextBox();
            lblPostparto = new Label();
            label26 = new Label();
            lbl2doTrim = new Label();
            lblsi3 = new Label();
            lblInfectPuerperal = new Label();
            gbAnemia = new GroupBox();
            rbnanemiaN = new RadioButton();
            rbnanemiaS = new RadioButton();
            gbRoturaPrem = new GroupBox();
            rbnroturaN = new RadioButton();
            rbnroturaS = new RadioButton();
            gbRCIU = new GroupBox();
            rbnRCIUn = new RadioButton();
            rbnRCIUs = new RadioButton();
            lblHTAprevia = new Label();
            gbInfecObular = new GroupBox();
            rbninfecobuN = new RadioButton();
            rbninfecobuS = new RadioButton();
            gbInfecUrinaria = new GroupBox();
            rbninfecuriN = new RadioButton();
            rbninfecuriS = new RadioButton();
            gbDiabetes = new GroupBox();
            rbndiabetes = new RadioButton();
            rbndiabetes1 = new RadioButton();
            rbndiabetes2 = new RadioButton();
            rbndiabetesG = new RadioButton();
            gbAmenazaPP = new GroupBox();
            rbnamenN = new RadioButton();
            rbnamenS = new RadioButton();
            gbNefropatía = new GroupBox();
            rbnnefroN = new RadioButton();
            rbnnefroS = new RadioButton();
            gbCardiopatía = new GroupBox();
            rbncardioN = new RadioButton();
            rbncardioS = new RadioButton();
            gbEclampsia = new GroupBox();
            rbneclampN = new RadioButton();
            rbneclampS = new RadioButton();
            gbHTAprevia = new GroupBox();
            rbnHTAn = new RadioButton();
            rbnHTAs = new RadioButton();
            lblOtraCondGrave = new Label();
            lblNo2 = new Label();
            lblAnemia = new Label();
            gbHTAinducidae = new GroupBox();
            rbnHTAindn = new RadioButton();
            rbnHTAinds = new RadioButton();
            lblRoturaPremM = new Label();
            lblSi2 = new Label();
            lblRCIU = new Label();
            gbPreeclampsia = new GroupBox();
            rbnpreeclamN = new RadioButton();
            rbnpreeclams = new RadioButton();
            lblAmenzaPartoPreter = new Label();
            lblHTAinde = new Label();
            lblInfecUrinaria = new Label();
            lblPreeclampsia = new Label();
            lblInfecObular = new Label();
            lblEclampsia = new Label();
            lblCardiopatía = new Label();
            lblNefropatía = new Label();
            lblDiabetes = new Label();
            lblSi1 = new Label();
            lblNo1 = new Label();
            rbn1omas = new RadioButton();
            rbnninguno = new RadioButton();
            btnfinalizar = new Button();
            erpNumeros = new ErrorProvider(components);
            btnRmenu = new Button();
            btnSalir4 = new Button();
            erpBoton = new ErrorProvider(components);
            gbEnfermedadesPM.SuspendLayout();
            gbTDPPRUEBA.SuspendLayout();
            gbSifilis.SuspendLayout();
            gbVIH.SuspendLayout();
            gbTARV.SuspendLayout();
            gbEnfermedades.SuspendLayout();
            gbOtraCondGrave.SuspendLayout();
            gbHemorragia.SuspendLayout();
            gbInfectPuerperal.SuspendLayout();
            gbPostparto.SuspendLayout();
            gb1erTrim.SuspendLayout();
            gb2doTrim.SuspendLayout();
            gb3erTrim.SuspendLayout();
            gbAnemia.SuspendLayout();
            gbRoturaPrem.SuspendLayout();
            gbRCIU.SuspendLayout();
            gbInfecObular.SuspendLayout();
            gbInfecUrinaria.SuspendLayout();
            gbDiabetes.SuspendLayout();
            gbAmenazaPP.SuspendLayout();
            gbNefropatía.SuspendLayout();
            gbCardiopatía.SuspendLayout();
            gbEclampsia.SuspendLayout();
            gbHTAprevia.SuspendLayout();
            gbHTAinducidae.SuspendLayout();
            gbPreeclampsia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)erpNumeros).BeginInit();
            ((System.ComponentModel.ISupportInitialize)erpBoton).BeginInit();
            SuspendLayout();
            // 
            // gbEnfermedadesPM
            // 
            gbEnfermedadesPM.BackColor = SystemColors.GradientInactiveCaption;
            gbEnfermedadesPM.Controls.Add(gbTDPPRUEBA);
            gbEnfermedadesPM.Controls.Add(gbTARV);
            gbEnfermedadesPM.Controls.Add(gbEnfermedades);
            gbEnfermedadesPM.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbEnfermedadesPM.Location = new Point(12, 12);
            gbEnfermedadesPM.Name = "gbEnfermedadesPM";
            gbEnfermedadesPM.Size = new Size(1016, 531);
            gbEnfermedadesPM.TabIndex = 0;
            gbEnfermedadesPM.TabStop = false;
            gbEnfermedadesPM.Text = "ENFERMEDADES (PATOLOGÍAS MATERNAS)";
            // 
            // gbTDPPRUEBA
            // 
            gbTDPPRUEBA.Controls.Add(gbSifilis);
            gbTDPPRUEBA.Controls.Add(label32);
            gbTDPPRUEBA.Controls.Add(gbVIH);
            gbTDPPRUEBA.Controls.Add(label31);
            gbTDPPRUEBA.Controls.Add(label30);
            gbTDPPRUEBA.Controls.Add(label29);
            gbTDPPRUEBA.Location = new Point(29, 402);
            gbTDPPRUEBA.Name = "gbTDPPRUEBA";
            gbTDPPRUEBA.Size = new Size(200, 122);
            gbTDPPRUEBA.TabIndex = 3;
            gbTDPPRUEBA.TabStop = false;
            gbTDPPRUEBA.Text = "TDP PRUEBA";
            // 
            // gbSifilis
            // 
            gbSifilis.Controls.Add(lblSifilis);
            gbSifilis.Controls.Add(rbnSifilisneg);
            gbSifilis.Controls.Add(rbnSifilispos);
            gbSifilis.Controls.Add(rbnSifilisnr);
            gbSifilis.Controls.Add(rbnsifilisnc);
            gbSifilis.Location = new Point(5, 41);
            gbSifilis.Name = "gbSifilis";
            gbSifilis.Size = new Size(174, 38);
            gbSifilis.TabIndex = 11;
            gbSifilis.TabStop = false;
            // 
            // lblSifilis
            // 
            lblSifilis.AutoSize = true;
            lblSifilis.Location = new Point(7, 15);
            lblSifilis.Name = "lblSifilis";
            lblSifilis.Size = new Size(41, 14);
            lblSifilis.TabIndex = 1;
            lblSifilis.Text = "Sifilis ";
            // 
            // rbnSifilisneg
            // 
            rbnSifilisneg.AutoSize = true;
            rbnSifilisneg.Location = new Point(56, 15);
            rbnSifilisneg.Name = "rbnSifilisneg";
            rbnSifilisneg.Size = new Size(14, 13);
            rbnSifilisneg.TabIndex = 0;
            rbnSifilisneg.TabStop = true;
            rbnSifilisneg.UseVisualStyleBackColor = true;
            // 
            // rbnSifilispos
            // 
            rbnSifilispos.AutoSize = true;
            rbnSifilispos.Location = new Point(87, 15);
            rbnSifilispos.Name = "rbnSifilispos";
            rbnSifilispos.Size = new Size(14, 13);
            rbnSifilispos.TabIndex = 3;
            rbnSifilispos.TabStop = true;
            rbnSifilispos.UseVisualStyleBackColor = true;
            // 
            // rbnSifilisnr
            // 
            rbnSifilisnr.AutoSize = true;
            rbnSifilisnr.Location = new Point(118, 15);
            rbnSifilisnr.Name = "rbnSifilisnr";
            rbnSifilisnr.Size = new Size(14, 13);
            rbnSifilisnr.TabIndex = 6;
            rbnSifilisnr.TabStop = true;
            rbnSifilisnr.UseVisualStyleBackColor = true;
            // 
            // rbnsifilisnc
            // 
            rbnsifilisnc.AutoSize = true;
            rbnsifilisnc.Location = new Point(148, 15);
            rbnsifilisnc.Name = "rbnsifilisnc";
            rbnsifilisnc.Size = new Size(14, 13);
            rbnsifilisnc.TabIndex = 8;
            rbnsifilisnc.TabStop = true;
            rbnsifilisnc.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(148, 23);
            label32.Name = "label32";
            label32.Size = new Size(24, 14);
            label32.TabIndex = 13;
            label32.Text = "n/c";
            // 
            // gbVIH
            // 
            gbVIH.Controls.Add(lblVIH);
            gbVIH.Controls.Add(rbnVIHnr);
            gbVIH.Controls.Add(rbnVIHnc);
            gbVIH.Controls.Add(rbnVIHposi);
            gbVIH.Controls.Add(rbnVIHneg);
            gbVIH.Location = new Point(6, 78);
            gbVIH.Name = "gbVIH";
            gbVIH.Size = new Size(174, 38);
            gbVIH.TabIndex = 10;
            gbVIH.TabStop = false;
            // 
            // lblVIH
            // 
            lblVIH.AutoSize = true;
            lblVIH.Location = new Point(6, 15);
            lblVIH.Name = "lblVIH";
            lblVIH.Size = new Size(28, 14);
            lblVIH.TabIndex = 2;
            lblVIH.Text = "VIH";
            // 
            // rbnVIHnr
            // 
            rbnVIHnr.AutoSize = true;
            rbnVIHnr.Location = new Point(118, 15);
            rbnVIHnr.Name = "rbnVIHnr";
            rbnVIHnr.Size = new Size(14, 13);
            rbnVIHnr.TabIndex = 5;
            rbnVIHnr.TabStop = true;
            rbnVIHnr.UseVisualStyleBackColor = true;
            // 
            // rbnVIHnc
            // 
            rbnVIHnc.AutoSize = true;
            rbnVIHnc.Location = new Point(148, 15);
            rbnVIHnc.Name = "rbnVIHnc";
            rbnVIHnc.Size = new Size(14, 13);
            rbnVIHnc.TabIndex = 7;
            rbnVIHnc.TabStop = true;
            rbnVIHnc.UseVisualStyleBackColor = true;
            // 
            // rbnVIHposi
            // 
            rbnVIHposi.AutoSize = true;
            rbnVIHposi.Location = new Point(87, 15);
            rbnVIHposi.Name = "rbnVIHposi";
            rbnVIHposi.Size = new Size(14, 13);
            rbnVIHposi.TabIndex = 4;
            rbnVIHposi.TabStop = true;
            rbnVIHposi.UseVisualStyleBackColor = true;
            // 
            // rbnVIHneg
            // 
            rbnVIHneg.AutoSize = true;
            rbnVIHneg.Location = new Point(55, 15);
            rbnVIHneg.Name = "rbnVIHneg";
            rbnVIHneg.Size = new Size(14, 13);
            rbnVIHneg.TabIndex = 9;
            rbnVIHneg.TabStop = true;
            rbnVIHneg.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(115, 23);
            label31.Name = "label31";
            label31.Size = new Size(22, 14);
            label31.TabIndex = 12;
            label31.Text = "n/r";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(91, 23);
            label30.Name = "label30";
            label30.Size = new Size(14, 14);
            label30.TabIndex = 11;
            label30.Text = "+";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(59, 23);
            label29.Name = "label29";
            label29.Size = new Size(11, 14);
            label29.TabIndex = 10;
            label29.Text = "-";
            // 
            // gbTARV
            // 
            gbTARV.Controls.Add(rbnTARVnc);
            gbTARV.Controls.Add(rbnTARVn);
            gbTARV.Controls.Add(rbnTARVs);
            gbTARV.Location = new Point(269, 402);
            gbTARV.Name = "gbTARV";
            gbTARV.Size = new Size(60, 122);
            gbTARV.TabIndex = 4;
            gbTARV.TabStop = false;
            gbTARV.Text = "TARV";
            // 
            // rbnTARVnc
            // 
            rbnTARVnc.AutoSize = true;
            rbnTARVnc.Location = new Point(6, 80);
            rbnTARVnc.Name = "rbnTARVnc";
            rbnTARVnc.Size = new Size(42, 18);
            rbnTARVnc.TabIndex = 2;
            rbnTARVnc.TabStop = true;
            rbnTARVnc.Text = "n/c";
            rbnTARVnc.UseVisualStyleBackColor = true;
            // 
            // rbnTARVn
            // 
            rbnTARVn.AutoSize = true;
            rbnTARVn.Location = new Point(6, 55);
            rbnTARVn.Name = "rbnTARVn";
            rbnTARVn.Size = new Size(41, 18);
            rbnTARVn.TabIndex = 1;
            rbnTARVn.TabStop = true;
            rbnTARVn.Text = "No";
            rbnTARVn.UseVisualStyleBackColor = true;
            // 
            // rbnTARVs
            // 
            rbnTARVs.AutoSize = true;
            rbnTARVs.Location = new Point(6, 31);
            rbnTARVs.Name = "rbnTARVs";
            rbnTARVs.Size = new Size(36, 18);
            rbnTARVs.TabIndex = 0;
            rbnTARVs.TabStop = true;
            rbnTARVs.Text = "Si";
            rbnTARVs.UseVisualStyleBackColor = true;
            // 
            // gbEnfermedades
            // 
            gbEnfermedades.Controls.Add(gbOtraCondGrave);
            gbEnfermedades.Controls.Add(gbHemorragia);
            gbEnfermedades.Controls.Add(gbAnemia);
            gbEnfermedades.Controls.Add(gbRoturaPrem);
            gbEnfermedades.Controls.Add(gbRCIU);
            gbEnfermedades.Controls.Add(lblHTAprevia);
            gbEnfermedades.Controls.Add(gbInfecObular);
            gbEnfermedades.Controls.Add(gbInfecUrinaria);
            gbEnfermedades.Controls.Add(gbDiabetes);
            gbEnfermedades.Controls.Add(gbAmenazaPP);
            gbEnfermedades.Controls.Add(gbNefropatía);
            gbEnfermedades.Controls.Add(gbCardiopatía);
            gbEnfermedades.Controls.Add(gbEclampsia);
            gbEnfermedades.Controls.Add(gbHTAprevia);
            gbEnfermedades.Controls.Add(lblOtraCondGrave);
            gbEnfermedades.Controls.Add(lblNo2);
            gbEnfermedades.Controls.Add(lblAnemia);
            gbEnfermedades.Controls.Add(gbHTAinducidae);
            gbEnfermedades.Controls.Add(lblRoturaPremM);
            gbEnfermedades.Controls.Add(lblSi2);
            gbEnfermedades.Controls.Add(lblRCIU);
            gbEnfermedades.Controls.Add(gbPreeclampsia);
            gbEnfermedades.Controls.Add(lblAmenzaPartoPreter);
            gbEnfermedades.Controls.Add(lblHTAinde);
            gbEnfermedades.Controls.Add(lblInfecUrinaria);
            gbEnfermedades.Controls.Add(lblPreeclampsia);
            gbEnfermedades.Controls.Add(lblInfecObular);
            gbEnfermedades.Controls.Add(lblEclampsia);
            gbEnfermedades.Controls.Add(lblCardiopatía);
            gbEnfermedades.Controls.Add(lblNefropatía);
            gbEnfermedades.Controls.Add(lblDiabetes);
            gbEnfermedades.Controls.Add(lblSi1);
            gbEnfermedades.Controls.Add(lblNo1);
            gbEnfermedades.Controls.Add(rbn1omas);
            gbEnfermedades.Controls.Add(rbnninguno);
            gbEnfermedades.Location = new Point(17, 22);
            gbEnfermedades.Name = "gbEnfermedades";
            gbEnfermedades.Size = new Size(989, 374);
            gbEnfermedades.TabIndex = 2;
            gbEnfermedades.TabStop = false;
            gbEnfermedades.Text = "ENFERMEDADES";
            // 
            // gbOtraCondGrave
            // 
            gbOtraCondGrave.Controls.Add(rbnotracondN);
            gbOtraCondGrave.Controls.Add(rbnotracondS);
            gbOtraCondGrave.Location = new Point(359, 320);
            gbOtraCondGrave.Name = "gbOtraCondGrave";
            gbOtraCondGrave.Size = new Size(69, 36);
            gbOtraCondGrave.TabIndex = 27;
            gbOtraCondGrave.TabStop = false;
            // 
            // rbnotracondN
            // 
            rbnotracondN.AutoSize = true;
            rbnotracondN.Location = new Point(6, 17);
            rbnotracondN.Name = "rbnotracondN";
            rbnotracondN.Size = new Size(14, 13);
            rbnotracondN.TabIndex = 2;
            rbnotracondN.TabStop = true;
            rbnotracondN.UseVisualStyleBackColor = true;
            // 
            // rbnotracondS
            // 
            rbnotracondS.AutoSize = true;
            rbnotracondS.Location = new Point(49, 17);
            rbnotracondS.Name = "rbnotracondS";
            rbnotracondS.Size = new Size(14, 13);
            rbnotracondS.TabIndex = 18;
            rbnotracondS.TabStop = true;
            rbnotracondS.UseVisualStyleBackColor = true;
            // 
            // gbHemorragia
            // 
            gbHemorragia.Controls.Add(gbInfectPuerperal);
            gbHemorragia.Controls.Add(txtpostparto);
            gbHemorragia.Controls.Add(lblNo3);
            gbHemorragia.Controls.Add(gbPostparto);
            gbHemorragia.Controls.Add(txt3er);
            gbHemorragia.Controls.Add(txtpuerperal);
            gbHemorragia.Controls.Add(gb1erTrim);
            gbHemorragia.Controls.Add(gb2doTrim);
            gbHemorragia.Controls.Add(lbl1erTrim);
            gbHemorragia.Controls.Add(txt2do);
            gbHemorragia.Controls.Add(gb3erTrim);
            gbHemorragia.Controls.Add(lbl3erTrim);
            gbHemorragia.Controls.Add(txt1er);
            gbHemorragia.Controls.Add(lblPostparto);
            gbHemorragia.Controls.Add(label26);
            gbHemorragia.Controls.Add(lbl2doTrim);
            gbHemorragia.Controls.Add(lblsi3);
            gbHemorragia.Controls.Add(lblInfectPuerperal);
            gbHemorragia.Location = new Point(660, 33);
            gbHemorragia.Name = "gbHemorragia";
            gbHemorragia.Size = new Size(305, 317);
            gbHemorragia.TabIndex = 55;
            gbHemorragia.TabStop = false;
            gbHemorragia.Text = "HEMORRAGIA";
            // 
            // gbInfectPuerperal
            // 
            gbInfectPuerperal.Controls.Add(rbninfectpuerpN);
            gbInfectPuerperal.Controls.Add(rbninfectpuerpS);
            gbInfectPuerperal.Location = new Point(113, 229);
            gbInfectPuerperal.Name = "gbInfectPuerperal";
            gbInfectPuerperal.Size = new Size(69, 36);
            gbInfectPuerperal.TabIndex = 29;
            gbInfectPuerperal.TabStop = false;
            // 
            // rbninfectpuerpN
            // 
            rbninfectpuerpN.AutoSize = true;
            rbninfectpuerpN.Location = new Point(6, 17);
            rbninfectpuerpN.Name = "rbninfectpuerpN";
            rbninfectpuerpN.Size = new Size(14, 13);
            rbninfectpuerpN.TabIndex = 2;
            rbninfectpuerpN.TabStop = true;
            rbninfectpuerpN.UseVisualStyleBackColor = true;
            // 
            // rbninfectpuerpS
            // 
            rbninfectpuerpS.AutoSize = true;
            rbninfectpuerpS.Location = new Point(49, 17);
            rbninfectpuerpS.Name = "rbninfectpuerpS";
            rbninfectpuerpS.Size = new Size(14, 13);
            rbninfectpuerpS.TabIndex = 18;
            rbninfectpuerpS.TabStop = true;
            rbninfectpuerpS.UseVisualStyleBackColor = true;
            // 
            // txtpostparto
            // 
            txtpostparto.Location = new Point(214, 194);
            txtpostparto.Name = "txtpostparto";
            txtpostparto.Size = new Size(42, 21);
            txtpostparto.TabIndex = 66;
            txtpostparto.TextChanged += txtpostparto_TextChanged;
            // 
            // lblNo3
            // 
            lblNo3.AutoSize = true;
            lblNo3.Location = new Point(119, 45);
            lblNo3.Name = "lblNo3";
            lblNo3.Size = new Size(23, 14);
            lblNo3.TabIndex = 60;
            lblNo3.Text = "No";
            // 
            // gbPostparto
            // 
            gbPostparto.Controls.Add(rbnpostpartoN);
            gbPostparto.Controls.Add(rbnpostpartoS);
            gbPostparto.Location = new Point(113, 187);
            gbPostparto.Name = "gbPostparto";
            gbPostparto.Size = new Size(69, 36);
            gbPostparto.TabIndex = 30;
            gbPostparto.TabStop = false;
            // 
            // rbnpostpartoN
            // 
            rbnpostpartoN.AutoSize = true;
            rbnpostpartoN.Location = new Point(6, 17);
            rbnpostpartoN.Name = "rbnpostpartoN";
            rbnpostpartoN.Size = new Size(14, 13);
            rbnpostpartoN.TabIndex = 2;
            rbnpostpartoN.TabStop = true;
            rbnpostpartoN.UseVisualStyleBackColor = true;
            // 
            // rbnpostpartoS
            // 
            rbnpostpartoS.AutoSize = true;
            rbnpostpartoS.Location = new Point(49, 17);
            rbnpostpartoS.Name = "rbnpostpartoS";
            rbnpostpartoS.Size = new Size(14, 13);
            rbnpostpartoS.TabIndex = 18;
            rbnpostpartoS.TabStop = true;
            rbnpostpartoS.UseVisualStyleBackColor = true;
            // 
            // txt3er
            // 
            txt3er.Location = new Point(214, 152);
            txt3er.Name = "txt3er";
            txt3er.Size = new Size(42, 21);
            txt3er.TabIndex = 65;
            txt3er.TextChanged += txt3er_TextChanged;
            // 
            // txtpuerperal
            // 
            txtpuerperal.Location = new Point(214, 236);
            txtpuerperal.Name = "txtpuerperal";
            txtpuerperal.Size = new Size(42, 21);
            txtpuerperal.TabIndex = 64;
            txtpuerperal.TextChanged += txtpuerperal_TextChanged;
            // 
            // gb1erTrim
            // 
            gb1erTrim.Controls.Add(rbn1ertrimN);
            gb1erTrim.Controls.Add(rbn1ertrimS);
            gb1erTrim.Location = new Point(113, 63);
            gb1erTrim.Name = "gb1erTrim";
            gb1erTrim.Size = new Size(69, 36);
            gb1erTrim.TabIndex = 28;
            gb1erTrim.TabStop = false;
            // 
            // rbn1ertrimN
            // 
            rbn1ertrimN.AutoSize = true;
            rbn1ertrimN.Location = new Point(6, 17);
            rbn1ertrimN.Name = "rbn1ertrimN";
            rbn1ertrimN.Size = new Size(14, 13);
            rbn1ertrimN.TabIndex = 2;
            rbn1ertrimN.TabStop = true;
            rbn1ertrimN.UseVisualStyleBackColor = true;
            // 
            // rbn1ertrimS
            // 
            rbn1ertrimS.AutoSize = true;
            rbn1ertrimS.Location = new Point(49, 17);
            rbn1ertrimS.Name = "rbn1ertrimS";
            rbn1ertrimS.Size = new Size(14, 13);
            rbn1ertrimS.TabIndex = 18;
            rbn1ertrimS.TabStop = true;
            rbn1ertrimS.UseVisualStyleBackColor = true;
            // 
            // gb2doTrim
            // 
            gb2doTrim.Controls.Add(rbn2dotrimN);
            gb2doTrim.Controls.Add(rbn2dotrimS);
            gb2doTrim.Location = new Point(113, 105);
            gb2doTrim.Name = "gb2doTrim";
            gb2doTrim.Size = new Size(69, 36);
            gb2doTrim.TabIndex = 31;
            gb2doTrim.TabStop = false;
            // 
            // rbn2dotrimN
            // 
            rbn2dotrimN.AutoSize = true;
            rbn2dotrimN.Location = new Point(6, 17);
            rbn2dotrimN.Name = "rbn2dotrimN";
            rbn2dotrimN.Size = new Size(14, 13);
            rbn2dotrimN.TabIndex = 2;
            rbn2dotrimN.TabStop = true;
            rbn2dotrimN.UseVisualStyleBackColor = true;
            // 
            // rbn2dotrimS
            // 
            rbn2dotrimS.AutoSize = true;
            rbn2dotrimS.Location = new Point(49, 17);
            rbn2dotrimS.Name = "rbn2dotrimS";
            rbn2dotrimS.Size = new Size(14, 13);
            rbn2dotrimS.TabIndex = 18;
            rbn2dotrimS.TabStop = true;
            rbn2dotrimS.UseVisualStyleBackColor = true;
            // 
            // lbl1erTrim
            // 
            lbl1erTrim.AutoSize = true;
            lbl1erTrim.Location = new Point(58, 79);
            lbl1erTrim.Name = "lbl1erTrim";
            lbl1erTrim.Size = new Size(56, 14);
            lbl1erTrim.TabIndex = 0;
            lbl1erTrim.Text = "1er Trim";
            // 
            // txt2do
            // 
            txt2do.Location = new Point(214, 113);
            txt2do.MaxLength = 2;
            txt2do.Name = "txt2do";
            txt2do.Size = new Size(42, 21);
            txt2do.TabIndex = 63;
            txt2do.TextChanged += txt2do_TextChanged;
            // 
            // gb3erTrim
            // 
            gb3erTrim.Controls.Add(rbn3ertrimN);
            gb3erTrim.Controls.Add(rbn3ertrimS);
            gb3erTrim.Location = new Point(113, 145);
            gb3erTrim.Name = "gb3erTrim";
            gb3erTrim.Size = new Size(69, 36);
            gb3erTrim.TabIndex = 27;
            gb3erTrim.TabStop = false;
            // 
            // rbn3ertrimN
            // 
            rbn3ertrimN.AutoSize = true;
            rbn3ertrimN.Location = new Point(6, 17);
            rbn3ertrimN.Name = "rbn3ertrimN";
            rbn3ertrimN.Size = new Size(14, 13);
            rbn3ertrimN.TabIndex = 2;
            rbn3ertrimN.TabStop = true;
            rbn3ertrimN.UseVisualStyleBackColor = true;
            // 
            // rbn3ertrimS
            // 
            rbn3ertrimS.AutoSize = true;
            rbn3ertrimS.Location = new Point(49, 17);
            rbn3ertrimS.Name = "rbn3ertrimS";
            rbn3ertrimS.Size = new Size(14, 13);
            rbn3ertrimS.TabIndex = 18;
            rbn3ertrimS.TabStop = true;
            rbn3ertrimS.UseVisualStyleBackColor = true;
            // 
            // lbl3erTrim
            // 
            lbl3erTrim.AutoSize = true;
            lbl3erTrim.Location = new Point(58, 160);
            lbl3erTrim.Name = "lbl3erTrim";
            lbl3erTrim.Size = new Size(56, 14);
            lbl3erTrim.TabIndex = 2;
            lbl3erTrim.Text = "3er Trim";
            // 
            // txt1er
            // 
            txt1er.Location = new Point(214, 70);
            txt1er.MaxLength = 2;
            txt1er.Name = "txt1er";
            txt1er.Size = new Size(42, 21);
            txt1er.TabIndex = 62;
            txt1er.TextChanged += txt1er_TextChanged;
            // 
            // lblPostparto
            // 
            lblPostparto.AutoSize = true;
            lblPostparto.Location = new Point(49, 202);
            lblPostparto.Name = "lblPostparto";
            lblPostparto.Size = new Size(64, 14);
            lblPostparto.TabIndex = 3;
            lblPostparto.Text = "Postparto";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(214, 45);
            label26.Name = "label26";
            label26.Size = new Size(49, 14);
            label26.TabIndex = 61;
            label26.Text = "Codigo";
            // 
            // lbl2doTrim
            // 
            lbl2doTrim.AutoSize = true;
            lbl2doTrim.Location = new Point(54, 121);
            lbl2doTrim.Name = "lbl2doTrim";
            lbl2doTrim.Size = new Size(59, 14);
            lbl2doTrim.TabIndex = 1;
            lbl2doTrim.Text = "2do Trim";
            // 
            // lblsi3
            // 
            lblsi3.AutoSize = true;
            lblsi3.Location = new Point(160, 45);
            lblsi3.Name = "lblsi3";
            lblsi3.Size = new Size(18, 14);
            lblsi3.TabIndex = 59;
            lblsi3.Text = "Si";
            // 
            // lblInfectPuerperal
            // 
            lblInfectPuerperal.AutoSize = true;
            lblInfectPuerperal.Location = new Point(14, 244);
            lblInfectPuerperal.Name = "lblInfectPuerperal";
            lblInfectPuerperal.Size = new Size(104, 14);
            lblInfectPuerperal.TabIndex = 4;
            lblInfectPuerperal.Text = "Infect. Puerperal";
            // 
            // gbAnemia
            // 
            gbAnemia.Controls.Add(rbnanemiaN);
            gbAnemia.Controls.Add(rbnanemiaS);
            gbAnemia.Location = new Point(359, 278);
            gbAnemia.Name = "gbAnemia";
            gbAnemia.Size = new Size(69, 36);
            gbAnemia.TabIndex = 23;
            gbAnemia.TabStop = false;
            // 
            // rbnanemiaN
            // 
            rbnanemiaN.AutoSize = true;
            rbnanemiaN.Location = new Point(6, 17);
            rbnanemiaN.Name = "rbnanemiaN";
            rbnanemiaN.Size = new Size(14, 13);
            rbnanemiaN.TabIndex = 2;
            rbnanemiaN.TabStop = true;
            rbnanemiaN.UseVisualStyleBackColor = true;
            // 
            // rbnanemiaS
            // 
            rbnanemiaS.AutoSize = true;
            rbnanemiaS.Location = new Point(49, 17);
            rbnanemiaS.Name = "rbnanemiaS";
            rbnanemiaS.Size = new Size(14, 13);
            rbnanemiaS.TabIndex = 18;
            rbnanemiaS.TabStop = true;
            rbnanemiaS.UseVisualStyleBackColor = true;
            // 
            // gbRoturaPrem
            // 
            gbRoturaPrem.Controls.Add(rbnroturaN);
            gbRoturaPrem.Controls.Add(rbnroturaS);
            gbRoturaPrem.Location = new Point(359, 236);
            gbRoturaPrem.Name = "gbRoturaPrem";
            gbRoturaPrem.Size = new Size(69, 36);
            gbRoturaPrem.TabIndex = 24;
            gbRoturaPrem.TabStop = false;
            // 
            // rbnroturaN
            // 
            rbnroturaN.AutoSize = true;
            rbnroturaN.Location = new Point(6, 17);
            rbnroturaN.Name = "rbnroturaN";
            rbnroturaN.Size = new Size(14, 13);
            rbnroturaN.TabIndex = 2;
            rbnroturaN.TabStop = true;
            rbnroturaN.UseVisualStyleBackColor = true;
            // 
            // rbnroturaS
            // 
            rbnroturaS.AutoSize = true;
            rbnroturaS.Location = new Point(49, 17);
            rbnroturaS.Name = "rbnroturaS";
            rbnroturaS.Size = new Size(14, 13);
            rbnroturaS.TabIndex = 18;
            rbnroturaS.TabStop = true;
            rbnroturaS.UseVisualStyleBackColor = true;
            // 
            // gbRCIU
            // 
            gbRCIU.Controls.Add(rbnRCIUn);
            gbRCIU.Controls.Add(rbnRCIUs);
            gbRCIU.Location = new Point(359, 194);
            gbRCIU.Name = "gbRCIU";
            gbRCIU.Size = new Size(69, 36);
            gbRCIU.TabIndex = 25;
            gbRCIU.TabStop = false;
            // 
            // rbnRCIUn
            // 
            rbnRCIUn.AutoSize = true;
            rbnRCIUn.Location = new Point(6, 17);
            rbnRCIUn.Name = "rbnRCIUn";
            rbnRCIUn.Size = new Size(14, 13);
            rbnRCIUn.TabIndex = 2;
            rbnRCIUn.TabStop = true;
            rbnRCIUn.UseVisualStyleBackColor = true;
            // 
            // rbnRCIUs
            // 
            rbnRCIUs.AutoSize = true;
            rbnRCIUs.Location = new Point(49, 17);
            rbnRCIUs.Name = "rbnRCIUs";
            rbnRCIUs.Size = new Size(14, 13);
            rbnRCIUs.TabIndex = 18;
            rbnRCIUs.TabStop = true;
            rbnRCIUs.UseVisualStyleBackColor = true;
            // 
            // lblHTAprevia
            // 
            lblHTAprevia.AutoSize = true;
            lblHTAprevia.Location = new Point(71, 85);
            lblHTAprevia.Name = "lblHTAprevia";
            lblHTAprevia.Size = new Size(76, 14);
            lblHTAprevia.TabIndex = 4;
            lblHTAprevia.Text = "HTA Previa ";
            // 
            // gbInfecObular
            // 
            gbInfecObular.Controls.Add(rbninfecobuN);
            gbInfecObular.Controls.Add(rbninfecobuS);
            gbInfecObular.Location = new Point(359, 70);
            gbInfecObular.Name = "gbInfecObular";
            gbInfecObular.Size = new Size(69, 36);
            gbInfecObular.TabIndex = 22;
            gbInfecObular.TabStop = false;
            // 
            // rbninfecobuN
            // 
            rbninfecobuN.AutoSize = true;
            rbninfecobuN.Location = new Point(6, 17);
            rbninfecobuN.Name = "rbninfecobuN";
            rbninfecobuN.Size = new Size(14, 13);
            rbninfecobuN.TabIndex = 2;
            rbninfecobuN.TabStop = true;
            rbninfecobuN.UseVisualStyleBackColor = true;
            // 
            // rbninfecobuS
            // 
            rbninfecobuS.AutoSize = true;
            rbninfecobuS.Location = new Point(49, 17);
            rbninfecobuS.Name = "rbninfecobuS";
            rbninfecobuS.Size = new Size(14, 13);
            rbninfecobuS.TabIndex = 18;
            rbninfecobuS.TabStop = true;
            rbninfecobuS.UseVisualStyleBackColor = true;
            // 
            // gbInfecUrinaria
            // 
            gbInfecUrinaria.Controls.Add(rbninfecuriN);
            gbInfecUrinaria.Controls.Add(rbninfecuriS);
            gbInfecUrinaria.Location = new Point(359, 112);
            gbInfecUrinaria.Name = "gbInfecUrinaria";
            gbInfecUrinaria.Size = new Size(69, 36);
            gbInfecUrinaria.TabIndex = 26;
            gbInfecUrinaria.TabStop = false;
            // 
            // rbninfecuriN
            // 
            rbninfecuriN.AutoSize = true;
            rbninfecuriN.Location = new Point(6, 17);
            rbninfecuriN.Name = "rbninfecuriN";
            rbninfecuriN.Size = new Size(14, 13);
            rbninfecuriN.TabIndex = 2;
            rbninfecuriN.TabStop = true;
            rbninfecuriN.UseVisualStyleBackColor = true;
            // 
            // rbninfecuriS
            // 
            rbninfecuriS.AutoSize = true;
            rbninfecuriS.Location = new Point(49, 17);
            rbninfecuriS.Name = "rbninfecuriS";
            rbninfecuriS.Size = new Size(14, 13);
            rbninfecuriS.TabIndex = 18;
            rbninfecuriS.TabStop = true;
            rbninfecuriS.UseVisualStyleBackColor = true;
            // 
            // gbDiabetes
            // 
            gbDiabetes.Controls.Add(rbndiabetes);
            gbDiabetes.Controls.Add(rbndiabetes1);
            gbDiabetes.Controls.Add(rbndiabetes2);
            gbDiabetes.Controls.Add(rbndiabetesG);
            gbDiabetes.Location = new Point(149, 320);
            gbDiabetes.Name = "gbDiabetes";
            gbDiabetes.Size = new Size(156, 36);
            gbDiabetes.TabIndex = 20;
            gbDiabetes.TabStop = false;
            // 
            // rbndiabetes
            // 
            rbndiabetes.AutoSize = true;
            rbndiabetes.Location = new Point(6, 17);
            rbndiabetes.Name = "rbndiabetes";
            rbndiabetes.Size = new Size(14, 13);
            rbndiabetes.TabIndex = 2;
            rbndiabetes.TabStop = true;
            rbndiabetes.UseVisualStyleBackColor = true;
            // 
            // rbndiabetes1
            // 
            rbndiabetes1.AutoSize = true;
            rbndiabetes1.Location = new Point(49, 13);
            rbndiabetes1.Name = "rbndiabetes1";
            rbndiabetes1.Size = new Size(29, 18);
            rbndiabetes1.TabIndex = 18;
            rbndiabetes1.TabStop = true;
            rbndiabetes1.Text = "I";
            rbndiabetes1.UseVisualStyleBackColor = true;
            // 
            // rbndiabetes2
            // 
            rbndiabetes2.AutoSize = true;
            rbndiabetes2.Location = new Point(83, 13);
            rbndiabetes2.Name = "rbndiabetes2";
            rbndiabetes2.Size = new Size(33, 18);
            rbndiabetes2.TabIndex = 54;
            rbndiabetes2.TabStop = true;
            rbndiabetes2.Text = "II";
            rbndiabetes2.UseVisualStyleBackColor = true;
            // 
            // rbndiabetesG
            // 
            rbndiabetesG.AutoSize = true;
            rbndiabetesG.Location = new Point(117, 13);
            rbndiabetesG.Name = "rbndiabetesG";
            rbndiabetesG.Size = new Size(35, 18);
            rbndiabetesG.TabIndex = 53;
            rbndiabetesG.TabStop = true;
            rbndiabetesG.Text = "G";
            rbndiabetesG.UseVisualStyleBackColor = true;
            // 
            // gbAmenazaPP
            // 
            gbAmenazaPP.Controls.Add(rbnamenN);
            gbAmenazaPP.Controls.Add(rbnamenS);
            gbAmenazaPP.Location = new Point(359, 152);
            gbAmenazaPP.Name = "gbAmenazaPP";
            gbAmenazaPP.Size = new Size(69, 36);
            gbAmenazaPP.TabIndex = 21;
            gbAmenazaPP.TabStop = false;
            // 
            // rbnamenN
            // 
            rbnamenN.AutoSize = true;
            rbnamenN.Location = new Point(6, 17);
            rbnamenN.Name = "rbnamenN";
            rbnamenN.Size = new Size(14, 13);
            rbnamenN.TabIndex = 2;
            rbnamenN.TabStop = true;
            rbnamenN.UseVisualStyleBackColor = true;
            // 
            // rbnamenS
            // 
            rbnamenS.AutoSize = true;
            rbnamenS.Location = new Point(49, 17);
            rbnamenS.Name = "rbnamenS";
            rbnamenS.Size = new Size(14, 13);
            rbnamenS.TabIndex = 18;
            rbnamenS.TabStop = true;
            rbnamenS.UseVisualStyleBackColor = true;
            // 
            // gbNefropatía
            // 
            gbNefropatía.Controls.Add(rbnnefroN);
            gbNefropatía.Controls.Add(rbnnefroS);
            gbNefropatía.Location = new Point(149, 278);
            gbNefropatía.Name = "gbNefropatía";
            gbNefropatía.Size = new Size(69, 36);
            gbNefropatía.TabIndex = 19;
            gbNefropatía.TabStop = false;
            // 
            // rbnnefroN
            // 
            rbnnefroN.AutoSize = true;
            rbnnefroN.Location = new Point(6, 17);
            rbnnefroN.Name = "rbnnefroN";
            rbnnefroN.Size = new Size(14, 13);
            rbnnefroN.TabIndex = 2;
            rbnnefroN.TabStop = true;
            rbnnefroN.UseVisualStyleBackColor = true;
            // 
            // rbnnefroS
            // 
            rbnnefroS.AutoSize = true;
            rbnnefroS.Location = new Point(49, 17);
            rbnnefroS.Name = "rbnnefroS";
            rbnnefroS.Size = new Size(14, 13);
            rbnnefroS.TabIndex = 18;
            rbnnefroS.TabStop = true;
            rbnnefroS.UseVisualStyleBackColor = true;
            // 
            // gbCardiopatía
            // 
            gbCardiopatía.Controls.Add(rbncardioN);
            gbCardiopatía.Controls.Add(rbncardioS);
            gbCardiopatía.Location = new Point(149, 236);
            gbCardiopatía.Name = "gbCardiopatía";
            gbCardiopatía.Size = new Size(69, 36);
            gbCardiopatía.TabIndex = 19;
            gbCardiopatía.TabStop = false;
            // 
            // rbncardioN
            // 
            rbncardioN.AutoSize = true;
            rbncardioN.Location = new Point(6, 17);
            rbncardioN.Name = "rbncardioN";
            rbncardioN.Size = new Size(14, 13);
            rbncardioN.TabIndex = 2;
            rbncardioN.TabStop = true;
            rbncardioN.UseVisualStyleBackColor = true;
            // 
            // rbncardioS
            // 
            rbncardioS.AutoSize = true;
            rbncardioS.Location = new Point(49, 17);
            rbncardioS.Name = "rbncardioS";
            rbncardioS.Size = new Size(14, 13);
            rbncardioS.TabIndex = 18;
            rbncardioS.TabStop = true;
            rbncardioS.UseVisualStyleBackColor = true;
            // 
            // gbEclampsia
            // 
            gbEclampsia.Controls.Add(rbneclampN);
            gbEclampsia.Controls.Add(rbneclampS);
            gbEclampsia.Location = new Point(149, 194);
            gbEclampsia.Name = "gbEclampsia";
            gbEclampsia.Size = new Size(69, 36);
            gbEclampsia.TabIndex = 19;
            gbEclampsia.TabStop = false;
            // 
            // rbneclampN
            // 
            rbneclampN.AutoSize = true;
            rbneclampN.Location = new Point(6, 17);
            rbneclampN.Name = "rbneclampN";
            rbneclampN.Size = new Size(14, 13);
            rbneclampN.TabIndex = 2;
            rbneclampN.TabStop = true;
            rbneclampN.UseVisualStyleBackColor = true;
            // 
            // rbneclampS
            // 
            rbneclampS.AutoSize = true;
            rbneclampS.Location = new Point(49, 17);
            rbneclampS.Name = "rbneclampS";
            rbneclampS.Size = new Size(14, 13);
            rbneclampS.TabIndex = 18;
            rbneclampS.TabStop = true;
            rbneclampS.UseVisualStyleBackColor = true;
            // 
            // gbHTAprevia
            // 
            gbHTAprevia.Controls.Add(rbnHTAn);
            gbHTAprevia.Controls.Add(rbnHTAs);
            gbHTAprevia.Location = new Point(149, 70);
            gbHTAprevia.Name = "gbHTAprevia";
            gbHTAprevia.Size = new Size(69, 36);
            gbHTAprevia.TabIndex = 3;
            gbHTAprevia.TabStop = false;
            // 
            // rbnHTAn
            // 
            rbnHTAn.AutoSize = true;
            rbnHTAn.Location = new Point(6, 17);
            rbnHTAn.Name = "rbnHTAn";
            rbnHTAn.Size = new Size(14, 13);
            rbnHTAn.TabIndex = 2;
            rbnHTAn.TabStop = true;
            rbnHTAn.UseVisualStyleBackColor = true;
            // 
            // rbnHTAs
            // 
            rbnHTAs.AutoSize = true;
            rbnHTAs.Location = new Point(49, 17);
            rbnHTAs.Name = "rbnHTAs";
            rbnHTAs.Size = new Size(14, 13);
            rbnHTAs.TabIndex = 18;
            rbnHTAs.TabStop = true;
            rbnHTAs.UseVisualStyleBackColor = true;
            // 
            // lblOtraCondGrave
            // 
            lblOtraCondGrave.AutoSize = true;
            lblOtraCondGrave.Location = new Point(452, 334);
            lblOtraCondGrave.Name = "lblOtraCondGrave";
            lblOtraCondGrave.Size = new Size(113, 14);
            lblOtraCondGrave.TabIndex = 28;
            lblOtraCondGrave.Text = "Otra Cond. Grave ";
            // 
            // lblNo2
            // 
            lblNo2.AutoSize = true;
            lblNo2.Location = new Point(365, 52);
            lblNo2.Name = "lblNo2";
            lblNo2.Size = new Size(23, 14);
            lblNo2.TabIndex = 40;
            lblNo2.Text = "No";
            // 
            // lblAnemia
            // 
            lblAnemia.AutoSize = true;
            lblAnemia.Location = new Point(452, 292);
            lblAnemia.Name = "lblAnemia";
            lblAnemia.Size = new Size(54, 14);
            lblAnemia.TabIndex = 31;
            lblAnemia.Text = "Anemia ";
            // 
            // gbHTAinducidae
            // 
            gbHTAinducidae.Controls.Add(rbnHTAindn);
            gbHTAinducidae.Controls.Add(rbnHTAinds);
            gbHTAinducidae.Location = new Point(149, 112);
            gbHTAinducidae.Name = "gbHTAinducidae";
            gbHTAinducidae.Size = new Size(69, 36);
            gbHTAinducidae.TabIndex = 19;
            gbHTAinducidae.TabStop = false;
            // 
            // rbnHTAindn
            // 
            rbnHTAindn.AutoSize = true;
            rbnHTAindn.Location = new Point(6, 17);
            rbnHTAindn.Name = "rbnHTAindn";
            rbnHTAindn.Size = new Size(14, 13);
            rbnHTAindn.TabIndex = 2;
            rbnHTAindn.TabStop = true;
            rbnHTAindn.UseVisualStyleBackColor = true;
            // 
            // rbnHTAinds
            // 
            rbnHTAinds.AutoSize = true;
            rbnHTAinds.Location = new Point(49, 17);
            rbnHTAinds.Name = "rbnHTAinds";
            rbnHTAinds.Size = new Size(14, 13);
            rbnHTAinds.TabIndex = 18;
            rbnHTAinds.TabStop = true;
            rbnHTAinds.UseVisualStyleBackColor = true;
            // 
            // lblRoturaPremM
            // 
            lblRoturaPremM.AutoSize = true;
            lblRoturaPremM.Location = new Point(453, 250);
            lblRoturaPremM.Name = "lblRoturaPremM";
            lblRoturaPremM.Size = new Size(177, 14);
            lblRoturaPremM.TabIndex = 30;
            lblRoturaPremM.Text = "Rotura Prem. de Membranas ";
            // 
            // lblSi2
            // 
            lblSi2.AutoSize = true;
            lblSi2.Location = new Point(406, 52);
            lblSi2.Name = "lblSi2";
            lblSi2.Size = new Size(18, 14);
            lblSi2.TabIndex = 39;
            lblSi2.Text = "Si";
            // 
            // lblRCIU
            // 
            lblRCIU.AutoSize = true;
            lblRCIU.Location = new Point(453, 209);
            lblRCIU.Name = "lblRCIU";
            lblRCIU.Size = new Size(50, 14);
            lblRCIU.TabIndex = 29;
            lblRCIU.Text = "R.C.I.U";
            // 
            // gbPreeclampsia
            // 
            gbPreeclampsia.Controls.Add(rbnpreeclamN);
            gbPreeclampsia.Controls.Add(rbnpreeclams);
            gbPreeclampsia.Location = new Point(149, 152);
            gbPreeclampsia.Name = "gbPreeclampsia";
            gbPreeclampsia.Size = new Size(69, 36);
            gbPreeclampsia.TabIndex = 2;
            gbPreeclampsia.TabStop = false;
            // 
            // rbnpreeclamN
            // 
            rbnpreeclamN.AutoSize = true;
            rbnpreeclamN.Location = new Point(6, 17);
            rbnpreeclamN.Name = "rbnpreeclamN";
            rbnpreeclamN.Size = new Size(14, 13);
            rbnpreeclamN.TabIndex = 2;
            rbnpreeclamN.TabStop = true;
            rbnpreeclamN.UseVisualStyleBackColor = true;
            // 
            // rbnpreeclams
            // 
            rbnpreeclams.AutoSize = true;
            rbnpreeclams.Location = new Point(49, 17);
            rbnpreeclams.Name = "rbnpreeclams";
            rbnpreeclams.Size = new Size(14, 13);
            rbnpreeclams.TabIndex = 18;
            rbnpreeclams.TabStop = true;
            rbnpreeclams.UseVisualStyleBackColor = true;
            // 
            // lblAmenzaPartoPreter
            // 
            lblAmenzaPartoPreter.AutoSize = true;
            lblAmenzaPartoPreter.Location = new Point(453, 166);
            lblAmenzaPartoPreter.Name = "lblAmenzaPartoPreter";
            lblAmenzaPartoPreter.Size = new Size(134, 14);
            lblAmenzaPartoPreter.TabIndex = 27;
            lblAmenzaPartoPreter.Text = "Amenaza Parto Preter";
            // 
            // lblHTAinde
            // 
            lblHTAinde.AutoSize = true;
            lblHTAinde.Location = new Point(57, 118);
            lblHTAinde.Name = "lblHTAinde";
            lblHTAinde.Size = new Size(87, 28);
            lblHTAinde.TabIndex = 5;
            lblHTAinde.Text = "HTA Inducida\r\nEmbarazo";
            // 
            // lblInfecUrinaria
            // 
            lblInfecUrinaria.AutoSize = true;
            lblInfecUrinaria.Location = new Point(452, 128);
            lblInfecUrinaria.Name = "lblInfecUrinaria";
            lblInfecUrinaria.Size = new Size(89, 14);
            lblInfecUrinaria.TabIndex = 26;
            lblInfecUrinaria.Text = "Infec. Urinaria";
            // 
            // lblPreeclampsia
            // 
            lblPreeclampsia.AutoSize = true;
            lblPreeclampsia.Location = new Point(57, 167);
            lblPreeclampsia.Name = "lblPreeclampsia";
            lblPreeclampsia.Size = new Size(87, 14);
            lblPreeclampsia.TabIndex = 6;
            lblPreeclampsia.Text = "Preeclampsia";
            // 
            // lblInfecObular
            // 
            lblInfecObular.AutoSize = true;
            lblInfecObular.Location = new Point(453, 86);
            lblInfecObular.Name = "lblInfecObular";
            lblInfecObular.Size = new Size(86, 14);
            lblInfecObular.TabIndex = 25;
            lblInfecObular.Text = "Infec. Obular ";
            // 
            // lblEclampsia
            // 
            lblEclampsia.AutoSize = true;
            lblEclampsia.Location = new Point(74, 209);
            lblEclampsia.Name = "lblEclampsia";
            lblEclampsia.Size = new Size(68, 14);
            lblEclampsia.TabIndex = 9;
            lblEclampsia.Text = "Eclampsia";
            // 
            // lblCardiopatía
            // 
            lblCardiopatía.AutoSize = true;
            lblCardiopatía.Location = new Point(64, 253);
            lblCardiopatía.Name = "lblCardiopatía";
            lblCardiopatía.Size = new Size(75, 14);
            lblCardiopatía.TabIndex = 7;
            lblCardiopatía.Text = "Cardiopatía";
            // 
            // lblNefropatía
            // 
            lblNefropatía.AutoSize = true;
            lblNefropatía.Location = new Point(69, 294);
            lblNefropatía.Name = "lblNefropatía";
            lblNefropatía.Size = new Size(68, 14);
            lblNefropatía.TabIndex = 8;
            lblNefropatía.Text = "Nefropatía";
            // 
            // lblDiabetes
            // 
            lblDiabetes.AutoSize = true;
            lblDiabetes.Location = new Point(80, 335);
            lblDiabetes.Name = "lblDiabetes";
            lblDiabetes.Size = new Size(59, 14);
            lblDiabetes.TabIndex = 10;
            lblDiabetes.Text = "Diabetes";
            // 
            // lblSi1
            // 
            lblSi1.AutoSize = true;
            lblSi1.Location = new Point(196, 52);
            lblSi1.Name = "lblSi1";
            lblSi1.Size = new Size(18, 14);
            lblSi1.TabIndex = 16;
            lblSi1.Text = "Si";
            // 
            // lblNo1
            // 
            lblNo1.AutoSize = true;
            lblNo1.Location = new Point(155, 52);
            lblNo1.Name = "lblNo1";
            lblNo1.Size = new Size(23, 14);
            lblNo1.TabIndex = 17;
            lblNo1.Text = "No";
            // 
            // rbn1omas
            // 
            rbn1omas.AutoSize = true;
            rbn1omas.Location = new Point(139, 22);
            rbn1omas.Name = "rbn1omas";
            rbn1omas.Size = new Size(69, 18);
            rbn1omas.TabIndex = 0;
            rbn1omas.Text = "1 ó Más";
            rbn1omas.UseVisualStyleBackColor = true;
            rbn1omas.CheckedChanged += rbn1omas_CheckedChanged;
            // 
            // rbnninguno
            // 
            rbnninguno.AutoSize = true;
            rbnninguno.Location = new Point(266, 22);
            rbnninguno.Name = "rbnninguno";
            rbnninguno.Size = new Size(73, 18);
            rbnninguno.TabIndex = 1;
            rbnninguno.TabStop = true;
            rbnninguno.Text = "Ninguna";
            rbnninguno.UseVisualStyleBackColor = true;
            // 
            // btnfinalizar
            // 
            btnfinalizar.BackColor = Color.LightSkyBlue;
            btnfinalizar.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnfinalizar.ForeColor = SystemColors.ControlLightLight;
            btnfinalizar.Location = new Point(920, 548);
            btnfinalizar.Margin = new Padding(2);
            btnfinalizar.Name = "btnfinalizar";
            btnfinalizar.Size = new Size(90, 26);
            btnfinalizar.TabIndex = 5;
            btnfinalizar.Text = "FINALIZAR";
            btnfinalizar.UseVisualStyleBackColor = false;
            btnfinalizar.Click += btnfinalizar_Click;
            // 
            // erpNumeros
            // 
            erpNumeros.ContainerControl = this;
            // 
            // btnRmenu
            // 
            btnRmenu.BackColor = Color.LightSkyBlue;
            btnRmenu.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRmenu.ForeColor = SystemColors.ControlLightLight;
            btnRmenu.Location = new Point(463, 548);
            btnRmenu.Margin = new Padding(2);
            btnRmenu.Name = "btnRmenu";
            btnRmenu.Size = new Size(147, 27);
            btnRmenu.TabIndex = 32;
            btnRmenu.TabStop = false;
            btnRmenu.Text = "REGRESAR AL MENU";
            btnRmenu.UseVisualStyleBackColor = false;
            btnRmenu.Click += btnRmenu_Click;
            // 
            // btnSalir4
            // 
            btnSalir4.BackColor = Color.LightSkyBlue;
            btnSalir4.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSalir4.ForeColor = SystemColors.ControlLightLight;
            btnSalir4.Location = new Point(27, 550);
            btnSalir4.Margin = new Padding(2);
            btnSalir4.Name = "btnSalir4";
            btnSalir4.Size = new Size(126, 23);
            btnSalir4.TabIndex = 31;
            btnSalir4.Text = "CERRAR SESION";
            btnSalir4.UseVisualStyleBackColor = false;
            btnSalir4.Click += btnSalir4_Click;
            // 
            // erpBoton
            // 
            erpBoton.ContainerControl = this;
            // 
            // ENFERMEDADES
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            AutoValidate = AutoValidate.EnablePreventFocusChange;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1037, 587);
            Controls.Add(btnRmenu);
            Controls.Add(btnSalir4);
            Controls.Add(btnfinalizar);
            Controls.Add(gbEnfermedadesPM);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "ENFERMEDADES";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ENFERMEDADES";
            gbEnfermedadesPM.ResumeLayout(false);
            gbTDPPRUEBA.ResumeLayout(false);
            gbTDPPRUEBA.PerformLayout();
            gbSifilis.ResumeLayout(false);
            gbSifilis.PerformLayout();
            gbVIH.ResumeLayout(false);
            gbVIH.PerformLayout();
            gbTARV.ResumeLayout(false);
            gbTARV.PerformLayout();
            gbEnfermedades.ResumeLayout(false);
            gbEnfermedades.PerformLayout();
            gbOtraCondGrave.ResumeLayout(false);
            gbOtraCondGrave.PerformLayout();
            gbHemorragia.ResumeLayout(false);
            gbHemorragia.PerformLayout();
            gbInfectPuerperal.ResumeLayout(false);
            gbInfectPuerperal.PerformLayout();
            gbPostparto.ResumeLayout(false);
            gbPostparto.PerformLayout();
            gb1erTrim.ResumeLayout(false);
            gb1erTrim.PerformLayout();
            gb2doTrim.ResumeLayout(false);
            gb2doTrim.PerformLayout();
            gb3erTrim.ResumeLayout(false);
            gb3erTrim.PerformLayout();
            gbAnemia.ResumeLayout(false);
            gbAnemia.PerformLayout();
            gbRoturaPrem.ResumeLayout(false);
            gbRoturaPrem.PerformLayout();
            gbRCIU.ResumeLayout(false);
            gbRCIU.PerformLayout();
            gbInfecObular.ResumeLayout(false);
            gbInfecObular.PerformLayout();
            gbInfecUrinaria.ResumeLayout(false);
            gbInfecUrinaria.PerformLayout();
            gbDiabetes.ResumeLayout(false);
            gbDiabetes.PerformLayout();
            gbAmenazaPP.ResumeLayout(false);
            gbAmenazaPP.PerformLayout();
            gbNefropatía.ResumeLayout(false);
            gbNefropatía.PerformLayout();
            gbCardiopatía.ResumeLayout(false);
            gbCardiopatía.PerformLayout();
            gbEclampsia.ResumeLayout(false);
            gbEclampsia.PerformLayout();
            gbHTAprevia.ResumeLayout(false);
            gbHTAprevia.PerformLayout();
            gbHTAinducidae.ResumeLayout(false);
            gbHTAinducidae.PerformLayout();
            gbPreeclampsia.ResumeLayout(false);
            gbPreeclampsia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)erpNumeros).EndInit();
            ((System.ComponentModel.ISupportInitialize)erpBoton).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gbEnfermedadesPM;
        private GroupBox gbEnfermedades;
        private Label lblDiabetes;
        private Label lblEclampsia;
        private Label lblNefropatía;
        private Label lblCardiopatía;
        private Label lblPreeclampsia;
        private Label lblHTAinde;
        private Label lblHTAprevia;
        private RadioButton rbnpreeclamN;
        private RadioButton rbnHTAn;
        private RadioButton rbn1omas;
        private RadioButton rbnninguno;
        private Label lblNo1;
        private Label lblSi1;
        private Label lblAnemia;
        private Label lblRoturaPremM;
        private Label lblRCIU;
        private Label lblOtraCondGrave;
        private Label lblAmenzaPartoPreter;
        private Label lblInfecUrinaria;
        private Label lblInfecObular;
        private RadioButton rbnpreeclams;
        private RadioButton rbnHTAs;
        private Label lblInfectPuerperal;
        private Label lblPostparto;
        private Label lbl3erTrim;
        private Label lbl2doTrim;
        private Label lbl1erTrim;
        private Label lblNo2;
        private Label lblSi2;
        private GroupBox gbTDPPRUEBA;
        private RadioButton rbndiabetes2;
        private RadioButton rbndiabetesG;
        private Label label26;
        private Label lblNo3;
        private Label lblsi3;
        private TextBox txtpostparto;
        private TextBox txt3er;
        private TextBox txtpuerperal;
        private TextBox txt2do;
        private TextBox txt1er;
        private GroupBox gbHemorragia;
        private GroupBox gbTARV;
        private Label label32;
        private Label label31;
        private Label label30;
        private Label label29;
        private RadioButton rbnVIHneg;
        private RadioButton rbnsifilisnc;
        private RadioButton rbnVIHnc;
        private RadioButton rbnSifilisnr;
        private RadioButton rbnVIHnr;
        private RadioButton rbnVIHposi;
        private RadioButton rbnSifilispos;
        private Label lblVIH;
        private Label lblSifilis;
        private RadioButton rbnSifilisneg;
        private RadioButton rbnTARVnc;
        private RadioButton rbnTARVn;
        private RadioButton rbnTARVs;
        private GroupBox gbHTAprevia;
        private GroupBox gbPreeclampsia;
        private GroupBox gbNefropatía;
        private RadioButton rbnnefroN;
        private RadioButton rbnnefroS;
        private GroupBox gbCardiopatía;
        private RadioButton rbncardioN;
        private RadioButton rbncardioS;
        private GroupBox gbHTAinducidae;
        private RadioButton rbnHTAindn;
        private RadioButton rbnHTAinds;
        private GroupBox gbEclampsia;
        private RadioButton rbneclampN;
        private RadioButton rbneclampS;
        private GroupBox gbDiabetes;
        private RadioButton rbndiabetes;
        private RadioButton rbndiabetes1;
        private GroupBox gbOtraCondGrave;
        private RadioButton rbnotracondN;
        private RadioButton rbnotracondS;
        private GroupBox gbAnemia;
        private RadioButton rbnanemiaN;
        private RadioButton rbnanemiaS;
        private GroupBox gbRoturaPrem;
        private RadioButton rbnroturaN;
        private RadioButton rbnroturaS;
        private GroupBox gbRCIU;
        private RadioButton rbnRCIUn;
        private RadioButton rbnRCIUs;
        private GroupBox gbInfecObular;
        private RadioButton rbninfecobuN;
        private RadioButton rbninfecobuS;
        private GroupBox gbInfecUrinaria;
        private RadioButton rbninfecuriN;
        private RadioButton rbninfecuriS;
        private GroupBox gbAmenazaPP;
        private RadioButton rbnamenN;
        private RadioButton rbnamenS;
        private GroupBox gbInfectPuerperal;
        private RadioButton rbninfectpuerpN;
        private RadioButton rbninfectpuerpS;
        private GroupBox gbPostparto;
        private RadioButton rbnpostpartoN;
        private RadioButton rbnpostpartoS;
        private GroupBox gb1erTrim;
        private RadioButton rbn1ertrimN;
        private RadioButton rbn1ertrimS;
        private GroupBox gb2doTrim;
        private RadioButton rbn2dotrimN;
        private RadioButton rbn2dotrimS;
        private GroupBox gb3erTrim;
        private RadioButton rbn3ertrimN;
        private RadioButton rbn3ertrimS;
        private ErrorProvider erpNumeros;
        private Button btnfinalizar;
        private GroupBox gbVIH;
        private GroupBox gbSifilis;
        private Button btnRmenu;
        private Button btnSalir4;
        private ErrorProvider erpBoton;
    }
}