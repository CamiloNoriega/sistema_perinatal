﻿namespace SISTEMA_INFORMATICO_PERINATAL
{
    partial class MENU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MENU));
            btnhcperinatal = new Button();
            btnAntecedentes = new Button();
            btnEnfermedades = new Button();
            btnSalirm = new Button();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            lblmenu = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // btnhcperinatal
            // 
            btnhcperinatal.BackColor = Color.LightSkyBlue;
            btnhcperinatal.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnhcperinatal.Location = new Point(127, 167);
            btnhcperinatal.Margin = new Padding(2);
            btnhcperinatal.Name = "btnhcperinatal";
            btnhcperinatal.Size = new Size(216, 20);
            btnhcperinatal.TabIndex = 0;
            btnhcperinatal.Text = "HISTORIA CLINCA PERINATAL";
            btnhcperinatal.UseVisualStyleBackColor = false;
            btnhcperinatal.Click += btnhcperinatal_Click;
            // 
            // btnAntecedentes
            // 
            btnAntecedentes.BackColor = Color.LightSkyBlue;
            btnAntecedentes.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAntecedentes.Location = new Point(170, 213);
            btnAntecedentes.Margin = new Padding(2);
            btnAntecedentes.Name = "btnAntecedentes";
            btnAntecedentes.Size = new Size(130, 20);
            btnAntecedentes.TabIndex = 1;
            btnAntecedentes.Text = "ANTECEDENTES";
            btnAntecedentes.UseVisualStyleBackColor = false;
            btnAntecedentes.Click += btnAntecedentes_Click;
            // 
            // btnEnfermedades
            // 
            btnEnfermedades.BackColor = Color.LightSkyBlue;
            btnEnfermedades.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEnfermedades.Location = new Point(170, 259);
            btnEnfermedades.Margin = new Padding(2);
            btnEnfermedades.Name = "btnEnfermedades";
            btnEnfermedades.Size = new Size(130, 20);
            btnEnfermedades.TabIndex = 2;
            btnEnfermedades.Text = "ENFERMEDADES";
            btnEnfermedades.UseVisualStyleBackColor = false;
            btnEnfermedades.Click += btnEnfermedades_Click;
            // 
            // btnSalirm
            // 
            btnSalirm.BackColor = Color.LightSkyBlue;
            btnSalirm.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSalirm.ForeColor = SystemColors.ControlLightLight;
            btnSalirm.Location = new Point(167, 305);
            btnSalirm.Name = "btnSalirm";
            btnSalirm.Size = new Size(136, 23);
            btnSalirm.TabIndex = 3;
            btnSalirm.Text = "CERRAR SESION";
            btnSalirm.UseVisualStyleBackColor = false;
            btnSalirm.Click += btnSalirm_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(215, 10);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(73, 65);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(369, 23);
            pictureBox2.Margin = new Padding(2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(93, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(39, 24);
            pictureBox3.Margin = new Padding(2);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(95, 37);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 7;
            pictureBox3.TabStop = false;
            // 
            // lblmenu
            // 
            lblmenu.AutoSize = true;
            lblmenu.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblmenu.ForeColor = Color.DarkBlue;
            lblmenu.Location = new Point(87, 113);
            lblmenu.Margin = new Padding(2, 0, 2, 0);
            lblmenu.Name = "lblmenu";
            lblmenu.Size = new Size(297, 28);
            lblmenu.TabIndex = 8;
            lblmenu.Text = "MENÚ DE NAVEGACIÓN";
            // 
            // MENU
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(490, 359);
            Controls.Add(lblmenu);
            Controls.Add(btnEnfermedades);
            Controls.Add(btnAntecedentes);
            Controls.Add(btnhcperinatal);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(btnSalirm);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(2);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "MENU";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MENU DE NAVEGACION";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnhcperinatal;
        private Button btnAntecedentes;
        private Button btnEnfermedades;
        private Button btnSalirm;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Label lblmenu;
    }
}