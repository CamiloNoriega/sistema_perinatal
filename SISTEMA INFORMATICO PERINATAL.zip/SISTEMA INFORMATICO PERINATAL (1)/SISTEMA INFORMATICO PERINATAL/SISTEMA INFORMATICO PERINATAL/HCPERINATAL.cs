﻿using System.Windows.Forms;

namespace SISTEMA_INFORMATICO_PERINATAL
{
    public partial class HCPERINATAL : Form
    {
       
        public HCPERINATAL()
        {
            InitializeComponent();
        }


        private void btnContnuar_Click(object sender, EventArgs e)
        {
            //validar listas desplegables
            bool comboBoxSelected = true;
            erpListas.Clear();
            // validar Estado Civil
            if (cmbEstadoCivil.SelectedIndex == -1)
            {
                erpListas.SetError(cmbEstadoCivil, "Seleccione un elemento.");
                comboBoxSelected = false;
            }
            // validar Estudios
            if (cmbEstudios.SelectedIndex == -1)
            {
                erpListas.SetError(cmbEstudios, "Seleccione un elemento.");
                comboBoxSelected = false;
            }
            // validar Etnia
            if (cmbEtnia.SelectedIndex == -1)
            {
                erpListas.SetError(cmbEtnia, "Seleccione un elemento.");
                comboBoxSelected = false;
            }

            //validar botones
            erpBoton.Clear();
            bool radioButtonChecked = true;
            // validar botones para alfabeta

            if (!(rbnalfabetaN.Checked || rbnalfabetaS.Checked))
            {
                erpBoton.SetError(gbAlfabeta, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnSolas.Checked || rbnSolan.Checked))
            {
                erpBoton.SetError(rbnSolan, "Seleccione una opción.");
                radioButtonChecked = false;
            }

            //validar cajas de texto
            bool textBoxcheked = true;
            // Validar TxtAños
            if (string.IsNullOrEmpty(TxtAños.Text) || !ValidarSoloNumeros(TxtAños, erpNumeros))
            {
                erpTexto.SetError(TxtAños, "Debe ingresar solo numeros.");
                textBoxcheked = false;
            }

            // Validar txtNombre
            if (string.IsNullOrEmpty(txtNombre.Text) || !ValidarSoloLetras(txtNombre, erpLetras))
            {
                erpTexto.SetError(txtNombre, "Debe ingresar solo caracteres.");
                textBoxcheked = false;
            }
            // Validar txtApellido
            if (string.IsNullOrEmpty(txtApellido.Text) || !ValidarSoloLetras(txtApellido, erpLetras))
            {
                erpTexto.SetError(txtApellido, "Debe ingresar solo caracteres.");
                textBoxcheked = false;
            }
            // Validar TxtTelefono
            if (string.IsNullOrEmpty(txtTelefono.Text) || !ValidarSoloNumeros(txtTelefono, erpNumeros))
            {
                erpTexto.SetError(txtTelefono, "Debe ingresar solo numeros.");
                textBoxcheked = false;
            }
            // validar txtLocalidad
            if (string.IsNullOrEmpty(txtLocalidad.Text) || !ValidarSoloLetras(txtLocalidad, erpLetras))
            {
                erpTexto.SetError(txtLocalidad, "Debe ingresar solo caracteres.");
                textBoxcheked = false;
            }
            //valdar txtañosmn
            if (string.IsNullOrEmpty(txtañosmn.Text) || !ValidarSoloNumeros(txtañosmn, erpNumeros))
            {
                erpTexto.SetError(txtañosmn, "Debe ingresar solo numeros.");
                textBoxcheked = false;
            }
            //validar txtlugarcontrol
            if (string.IsNullOrEmpty(txtlugarcontrol.Text) || !ValidarSoloNumeros(txtlugarcontrol, erpNumeros))
            {
                erpTexto.SetError(txtlugarcontrol, "Debe ingresar solo numeros.");
                textBoxcheked = false;
            }
            //validar txtlugarparto
            if (string.IsNullOrEmpty(txtlugarparto.Text) || !ValidarSoloNumeros(txtlugarparto, erpNumeros))
            {
                erpTexto.SetError(txtlugarparto, "Debe ingresar solo numeros.");
                textBoxcheked = false;
            }
            //validar txtnumeroidentidad
            if (string.IsNullOrEmpty(txtnumeroidentidad.Text) || !ValidarSoloNumeros(txtnumeroidentidad, erpNumeros))
            {
                erpTexto.SetError(txtnumeroidentidad, "Debe ingresar solo numeros.");
                textBoxcheked = false;
            }
            //validar txtDirección
            if (string.IsNullOrEmpty(txtDirección.Text))
            {
                erpTexto.SetError(txtDirección, "Debe diligenciar para continuar");
                textBoxcheked = false;
            }
            // Mostrar mensaje de advertencia para botones y listas
            if (!radioButtonChecked || !comboBoxSelected || !textBoxcheked)
            {
                MessageBox.Show("Corrija los errores antes de continuar, y verifique que todos los campos esten diligenciados");
                return;
            }

            ANTECEDENTES ven3 = new ANTECEDENTES();
            ven3.Show();
            this.Hide();
        }

        //funcion para validar numeros en interacciones
        private bool ValidarSoloNumeros(TextBox textBox, ErrorProvider errorProvider)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                errorProvider.SetError(textBox, "El campo no puede estar vacío");
                return false;
            }
            foreach (char caracter in textBox.Text)
            {
                if (!char.IsDigit(caracter) && caracter != ',')
                {
                    errorProvider.SetError(textBox, "No se admiten letras");
                    return false;
                }
            }

            errorProvider.Clear();
            return true;
        }
        //funcion para validar letras en interacciones
        private bool ValidarSoloLetras(TextBox textBox, ErrorProvider errorProvider)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                errorProvider.SetError(textBox, "El campo no puede estar vacío");
                return false;
            }
            foreach (char caracter in textBox.Text)
            {
                if (char.IsDigit(caracter))
                {
                    errorProvider.SetError(textBox, "No se admiten números");
                    return false;
                }
            }

            errorProvider.Clear();
            return true;
        }

        private void txtApellido_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloLetras(txtApellido, erpTexto);
        }

        private void TxtAños_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(TxtAños, erpTexto);
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloLetras(txtNombre, erpTexto);
        }

        private void txtTelefono_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtTelefono, erpTexto);
        }

        private void txtLocalidad_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloLetras(txtLocalidad, erpTexto);
        }

        private void txtañosmn_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtañosmn, erpTexto);
        }

        private void txtlugarcontrol_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtlugarcontrol, erpTexto);
        }

        private void txtlugarparto_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtlugarparto, erpTexto);
        }

        private void txtnumeroidentidad_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtnumeroidentidad, erpTexto);
        }

        private void btnSalir2_Click(object sender, EventArgs e)
        {
            REGISTRO ven1 = new REGISTRO();
            ven1.Show();
            this.Hide();
            MessageBox.Show("Su sesion ha sido cerrada exitosamente");
        }

        private void btnRmenu_Click(object sender, EventArgs e)
        {
            MENU ven2 = new MENU();
            ven2.Show();
            this.Hide();
        }
    }
}

