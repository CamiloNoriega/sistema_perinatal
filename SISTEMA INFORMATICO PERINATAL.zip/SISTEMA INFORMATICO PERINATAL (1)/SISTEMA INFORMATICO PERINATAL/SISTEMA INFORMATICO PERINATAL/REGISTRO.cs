namespace SISTEMA_INFORMATICO_PERINATAL
{
    public partial class REGISTRO : Form
    {
        public REGISTRO()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "Invitado" && txtContrase�a.Text == "12345678")
            {
                MessageBox.Show("BIENVENIDO");
                MENU ven2 = new MENU();
                ven2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("ACCESO DENEGADO");
                txtUsuario.Clear();
                txtContrase�a.Clear();

            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
