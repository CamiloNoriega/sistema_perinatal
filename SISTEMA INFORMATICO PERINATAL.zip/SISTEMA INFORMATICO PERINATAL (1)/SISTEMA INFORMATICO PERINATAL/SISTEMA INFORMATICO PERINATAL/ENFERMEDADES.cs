﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace SISTEMA_INFORMATICO_PERINATAL
{
    public partial class ENFERMEDADES : Form
    {
        public ENFERMEDADES()
        {
            InitializeComponent();
        }

        private void btnfinalizar_Click(object sender, EventArgs e)
        {
            bool radioButtonChecked = true;

            // Limpiar cualquier mensaje de error previo
            erpBoton.Clear();

            // Validar cada grupo de RadioButtons y establecer mensajes de error si no están seleccionados
            if (!(rbn1omas.Checked || rbnninguno.Checked))
            {
                erpBoton.SetError(rbn1omas, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnHTAn.Checked || rbnHTAs.Checked))
            {
                erpBoton.SetError(gbHTAprevia, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnHTAindn.Checked || rbnHTAinds.Checked))
            {
                erpBoton.SetError(gbHTAinducidae, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnpreeclamN.Checked || rbnpreeclams.Checked))
            {
                erpBoton.SetError(gbPreeclampsia, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbneclampN.Checked || rbneclampS.Checked))
            {
                erpBoton.SetError(gbEclampsia, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbncardioN.Checked || rbncardioS.Checked))
            {
                erpBoton.SetError(gbCardiopatía, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnnefroN.Checked || rbnnefroS.Checked))
            {
                erpBoton.SetError(gbNefropatía, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbninfecobuN.Checked || rbninfecobuS.Checked))
            {
                erpBoton.SetError(gbInfecObular, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbninfecuriN.Checked || rbninfecuriS.Checked))
            {
                erpBoton.SetError(gbInfecUrinaria, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnamenN.Checked || rbnamenS.Checked))
            {
                erpBoton.SetError(gbAmenazaPP, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnRCIUn.Checked || rbnRCIUs.Checked))
            {
                erpBoton.SetError(gbRCIU, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnroturaN.Checked || rbnroturaS.Checked))
            {
                erpBoton.SetError(gbRoturaPrem, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnanemiaN.Checked || rbnanemiaS.Checked))
            {
                erpBoton.SetError(gbAnemia, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnotracondN.Checked || rbnotracondS.Checked))
            {
                erpBoton.SetError(gbOtraCondGrave, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbn1ertrimN.Checked || rbn1ertrimS.Checked))
            {
                erpBoton.SetError(gb1erTrim, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbn2dotrimN.Checked || rbn2dotrimS.Checked))
            {
                erpBoton.SetError(gb2doTrim, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbn3ertrimN.Checked || rbn3ertrimS.Checked))
            {
                erpBoton.SetError(gb3erTrim, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnpostpartoN.Checked || rbnpostpartoS.Checked))
            {
                erpBoton.SetError(gbPostparto, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbninfectpuerpN.Checked || rbninfectpuerpS.Checked))
            {
                erpBoton.SetError(gbInfectPuerperal, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbndiabetes.Checked || rbndiabetes1.Checked || rbndiabetes2.Checked || rbndiabetesG.Checked))
            {
                erpBoton.SetError(gbDiabetes, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnTARVn.Checked || rbnTARVs.Checked || rbnTARVnc.Checked))
            {
                erpBoton.SetError(gbTARV, "Seleccione una opción.");
                
                radioButtonChecked = false;
            }
            if (!(rbnSifilisneg.Checked || rbnSifilispos.Checked || rbnSifilisnr.Checked || rbnsifilisnc.Checked))
            {
                erpBoton.SetError(gbSifilis, "Seleccione una opción.");

                radioButtonChecked = false;
            }
            if (!(rbnVIHneg.Checked || rbnVIHposi.Checked || rbnVIHnr.Checked || rbnVIHnc.Checked))
            {
                erpBoton.SetError(gbVIH, "Seleccione una opción.");

                radioButtonChecked = false;
            }


            bool textCheked = true;
            //Validar 1er codigo
            if (string.IsNullOrEmpty(txt1er.Text) || !ValidarSoloNumeros(txt1er, erpNumeros))
            {
                erpNumeros.SetError(txt1er, "Debe ingresar solo numeros.");
                textCheked = false;

            }
            //validar txt2do codigo
            if (string.IsNullOrEmpty(txt2do.Text) || !ValidarSoloNumeros(txt2do, erpNumeros))
            {
                erpNumeros.SetError(txt2do, "Debe ingresar solo numeros.");
                textCheked = false;

            }
            //validar txt3er codigo
            if (string.IsNullOrEmpty(txt3er.Text) || !ValidarSoloNumeros(txt3er, erpNumeros))
            {
                erpNumeros.SetError(txt3er, "Debe ingresar solo numeros.");
                textCheked = false;

            }
            //validar txtpostparto
            if (string.IsNullOrEmpty(txtpostparto.Text) || !ValidarSoloNumeros(txtpostparto, erpNumeros))
            {
                erpNumeros.SetError(txtpostparto, "Debe ingresar solo numeros.");
                textCheked = false;

            }
            //validar txtpuerperal
            if (string.IsNullOrEmpty(txtpuerperal.Text) || !ValidarSoloNumeros(txtpuerperal, erpNumeros))
            {
                erpNumeros.SetError(txtpuerperal, "Debe ingresar solo numeros.");
                textCheked = false;
            }
            // Mostrar mensaje de advertencia para botones cajas de texto
            if (!radioButtonChecked || !textCheked)
            {
                MessageBox.Show("Corrija los errores antes de finalizar, y verifique que todos los campos esten diligenciados");
                return;
            }

            REGISTRO ven1 = new REGISTRO();
            ven1.Show();
            this.Hide();
            MessageBox.Show("El formulario fue diligenciado de forma exitosa.");

        }
        //funcion para vakidar en interacciones
        private bool ValidarSoloNumeros(TextBox textBox, ErrorProvider errorProvider)
        {
            foreach (char caracter in textBox.Text)
            {
                if (!char.IsDigit(caracter) && caracter != ',')
                {
                    errorProvider.SetError(textBox, "No se admiten letras");
                    return false;
                }
            }

            errorProvider.Clear();
            return true;
        }

        private void txt2do_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txt2do, erpNumeros);
        }

        private void txt3er_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txt3er, erpNumeros);
        }

        private void txtpostparto_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtpostparto, erpNumeros);
        }

        private void txtpuerperal_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtpuerperal, erpNumeros);
        }
        private void txt1er_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txt1er, erpNumeros);
        }
        private void rbn1omas_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnRmenu_Click(object sender, EventArgs e)
        {
            MENU ven2 = new MENU();
            ven2.Show();
            this.Hide();
        }

        private void btnSalir4_Click(object sender, EventArgs e)
        {
            REGISTRO ven1 = new REGISTRO();
            ven1.Show();
            this.Hide();
            MessageBox.Show("Su sesion ha sido cerrada exitosamente");
        }
    }
}