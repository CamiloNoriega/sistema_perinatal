﻿namespace SISTEMA_INFORMATICO_PERINATAL
{
    partial class HCPERINATAL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HCPERINATAL));
            btnContnuar = new Button();
            gbHistoriaClínicaP = new GroupBox();
            gbLugar = new GroupBox();
            txtnumeroidentidad = new TextBox();
            txtlugarparto = new TextBox();
            lblIdentidad = new Label();
            lblLugarPA = new Label();
            lblLugarCP = new Label();
            txtlugarcontrol = new TextBox();
            gbEstadoCivil = new GroupBox();
            rbnSolan = new RadioButton();
            rbnSolas = new RadioButton();
            lblViveSola = new Label();
            cmbEstadoCivil = new ComboBox();
            gbEstudios = new GroupBox();
            gbAñoalto = new GroupBox();
            txtañosmn = new TextBox();
            gbNivelEstud = new GroupBox();
            cmbEstudios = new ComboBox();
            label9 = new Label();
            gbAlfabeta = new GroupBox();
            rbnalfabetaS = new RadioButton();
            rbnalfabetaN = new RadioButton();
            lbllleerescribir = new Label();
            gbFecha = new GroupBox();
            rbnAños = new RadioButton();
            dtpFechaN = new DateTimePicker();
            lblFechaN = new Label();
            TxtAños = new TextBox();
            lblAñosCumplidos = new Label();
            gbEtnia = new GroupBox();
            lblEtniaConsidera = new Label();
            cmbEtnia = new ComboBox();
            gbNombApelli = new GroupBox();
            txtLocalidad = new TextBox();
            txtApellido = new TextBox();
            txtTelefono = new TextBox();
            txtDirección = new TextBox();
            loblLocalidad = new Label();
            lblTeléfono = new Label();
            lblDirección = new Label();
            txtNombre = new TextBox();
            lblApellido = new Label();
            lblNombre = new Label();
            btnSalir2 = new Button();
            btnRmenu = new Button();
            erpBoton = new ErrorProvider(components);
            erpListas = new ErrorProvider(components);
            erpTexto = new ErrorProvider(components);
            gbHistoriaClínicaP.SuspendLayout();
            gbLugar.SuspendLayout();
            gbEstadoCivil.SuspendLayout();
            gbEstudios.SuspendLayout();
            gbAñoalto.SuspendLayout();
            gbNivelEstud.SuspendLayout();
            gbAlfabeta.SuspendLayout();
            gbFecha.SuspendLayout();
            gbEtnia.SuspendLayout();
            gbNombApelli.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)erpBoton).BeginInit();
            ((System.ComponentModel.ISupportInitialize)erpListas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)erpTexto).BeginInit();
            SuspendLayout();
            // 
            // btnContnuar
            // 
            btnContnuar.BackColor = Color.LightSkyBlue;
            btnContnuar.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnContnuar.ForeColor = SystemColors.ControlLightLight;
            btnContnuar.Location = new Point(580, 561);
            btnContnuar.Name = "btnContnuar";
            btnContnuar.Size = new Size(104, 30);
            btnContnuar.TabIndex = 1;
            btnContnuar.Text = "CONTINUAR>>";
            btnContnuar.UseVisualStyleBackColor = false;
            btnContnuar.Click += btnContnuar_Click;
            // 
            // gbHistoriaClínicaP
            // 
            gbHistoriaClínicaP.BackColor = SystemColors.GradientInactiveCaption;
            gbHistoriaClínicaP.Controls.Add(gbLugar);
            gbHistoriaClínicaP.Controls.Add(gbEstadoCivil);
            gbHistoriaClínicaP.Controls.Add(gbEstudios);
            gbHistoriaClínicaP.Controls.Add(gbAlfabeta);
            gbHistoriaClínicaP.Controls.Add(gbFecha);
            gbHistoriaClínicaP.Controls.Add(gbEtnia);
            gbHistoriaClínicaP.Controls.Add(gbNombApelli);
            gbHistoriaClínicaP.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbHistoriaClínicaP.Location = new Point(12, 12);
            gbHistoriaClínicaP.Name = "gbHistoriaClínicaP";
            gbHistoriaClínicaP.Size = new Size(699, 532);
            gbHistoriaClínicaP.TabIndex = 0;
            gbHistoriaClínicaP.TabStop = false;
            gbHistoriaClínicaP.Text = "Historia Clínica Perinatal";
            // 
            // gbLugar
            // 
            gbLugar.Controls.Add(txtnumeroidentidad);
            gbLugar.Controls.Add(txtlugarparto);
            gbLugar.Controls.Add(lblIdentidad);
            gbLugar.Controls.Add(lblLugarPA);
            gbLugar.Controls.Add(lblLugarCP);
            gbLugar.Controls.Add(txtlugarcontrol);
            gbLugar.Location = new Point(6, 446);
            gbLugar.Name = "gbLugar";
            gbLugar.Size = new Size(666, 73);
            gbLugar.TabIndex = 27;
            gbLugar.TabStop = false;
            // 
            // txtnumeroidentidad
            // 
            txtnumeroidentidad.Location = new Point(461, 40);
            txtnumeroidentidad.MaxLength = 10;
            txtnumeroidentidad.Name = "txtnumeroidentidad";
            txtnumeroidentidad.Size = new Size(165, 21);
            txtnumeroidentidad.TabIndex = 5;
            txtnumeroidentidad.TextChanged += txtnumeroidentidad_TextChanged;
            // 
            // txtlugarparto
            // 
            txtlugarparto.Location = new Point(251, 40);
            txtlugarparto.MaxLength = 8;
            txtlugarparto.Name = "txtlugarparto";
            txtlugarparto.Size = new Size(165, 21);
            txtlugarparto.TabIndex = 4;
            txtlugarparto.TextChanged += txtlugarparto_TextChanged;
            // 
            // lblIdentidad
            // 
            lblIdentidad.AutoSize = true;
            lblIdentidad.Location = new Point(461, 19);
            lblIdentidad.Name = "lblIdentidad";
            lblIdentidad.Size = new Size(157, 14);
            lblIdentidad.TabIndex = 3;
            lblIdentidad.Text = "NUMERO DE IDENTIDAD ";
            // 
            // lblLugarPA
            // 
            lblLugarPA.AutoSize = true;
            lblLugarPA.Location = new Point(241, 19);
            lblLugarPA.Name = "lblLugarPA";
            lblLugarPA.Size = new Size(183, 14);
            lblLugarPA.TabIndex = 2;
            lblLugarPA.Text = "LUGAR DEL PARTO/ABORTO";
            // 
            // lblLugarCP
            // 
            lblLugarCP.AutoSize = true;
            lblLugarCP.Location = new Point(9, 19);
            lblLugarCP.Name = "lblLugarCP";
            lblLugarCP.Size = new Size(206, 14);
            lblLugarCP.TabIndex = 1;
            lblLugarCP.Text = "LUGAR DE CONTROL PRENATAL";
            // 
            // txtlugarcontrol
            // 
            txtlugarcontrol.Location = new Point(19, 40);
            txtlugarcontrol.MaxLength = 8;
            txtlugarcontrol.Name = "txtlugarcontrol";
            txtlugarcontrol.Size = new Size(176, 21);
            txtlugarcontrol.TabIndex = 0;
            txtlugarcontrol.TextChanged += txtlugarcontrol_TextChanged;
            // 
            // gbEstadoCivil
            // 
            gbEstadoCivil.Controls.Add(rbnSolan);
            gbEstadoCivil.Controls.Add(rbnSolas);
            gbEstadoCivil.Controls.Add(lblViveSola);
            gbEstadoCivil.Controls.Add(cmbEstadoCivil);
            gbEstadoCivil.Location = new Point(6, 382);
            gbEstadoCivil.Name = "gbEstadoCivil";
            gbEstadoCivil.Size = new Size(408, 58);
            gbEstadoCivil.TabIndex = 26;
            gbEstadoCivil.TabStop = false;
            gbEstadoCivil.Text = "ESTADO CIVIL";
            // 
            // rbnSolan
            // 
            rbnSolan.AutoSize = true;
            rbnSolan.Location = new Point(324, 21);
            rbnSolan.Name = "rbnSolan";
            rbnSolan.Size = new Size(41, 18);
            rbnSolan.TabIndex = 32;
            rbnSolan.TabStop = true;
            rbnSolan.Text = "No";
            rbnSolan.UseVisualStyleBackColor = true;
            // 
            // rbnSolas
            // 
            rbnSolas.AutoSize = true;
            rbnSolas.Location = new Point(261, 21);
            rbnSolas.Name = "rbnSolas";
            rbnSolas.Size = new Size(36, 18);
            rbnSolas.TabIndex = 31;
            rbnSolas.TabStop = true;
            rbnSolas.Text = "Si";
            rbnSolas.UseVisualStyleBackColor = true;
            // 
            // lblViveSola
            // 
            lblViveSola.AutoSize = true;
            lblViveSola.Location = new Point(165, 23);
            lblViveSola.Name = "lblViveSola";
            lblViveSola.Size = new Size(73, 14);
            lblViveSola.TabIndex = 30;
            lblViveSola.Text = "¿Vive sola?";
            // 
            // cmbEstadoCivil
            // 
            cmbEstadoCivil.FormattingEnabled = true;
            cmbEstadoCivil.Items.AddRange(new object[] { "Soltera", "Casada", "Union Libre", "Otro" });
            cmbEstadoCivil.Location = new Point(16, 20);
            cmbEstadoCivil.Name = "cmbEstadoCivil";
            cmbEstadoCivil.Size = new Size(121, 22);
            cmbEstadoCivil.TabIndex = 28;
            // 
            // gbEstudios
            // 
            gbEstudios.Controls.Add(gbAñoalto);
            gbEstudios.Controls.Add(gbNivelEstud);
            gbEstudios.Controls.Add(label9);
            gbEstudios.Location = new Point(6, 287);
            gbEstudios.Name = "gbEstudios";
            gbEstudios.Size = new Size(666, 89);
            gbEstudios.TabIndex = 21;
            gbEstudios.TabStop = false;
            gbEstudios.Text = "ESTUDIOS";
            // 
            // gbAñoalto
            // 
            gbAñoalto.Controls.Add(txtañosmn);
            gbAñoalto.Location = new Point(360, 23);
            gbAñoalto.Name = "gbAñoalto";
            gbAñoalto.Size = new Size(244, 50);
            gbAñoalto.TabIndex = 6;
            gbAñoalto.TabStop = false;
            gbAñoalto.Text = "¿Cuál fue el año más alto que aprobó en ese nivel?";
            // 
            // txtañosmn
            // 
            txtañosmn.Location = new Point(150, 22);
            txtañosmn.Margin = new Padding(2);
            txtañosmn.MaxLength = 2;
            txtañosmn.Name = "txtañosmn";
            txtañosmn.Size = new Size(47, 21);
            txtañosmn.TabIndex = 0;
            txtañosmn.TextChanged += txtañosmn_TextChanged;
            // 
            // gbNivelEstud
            // 
            gbNivelEstud.Controls.Add(cmbEstudios);
            gbNivelEstud.Location = new Point(67, 23);
            gbNivelEstud.Name = "gbNivelEstud";
            gbNivelEstud.Size = new Size(244, 50);
            gbNivelEstud.TabIndex = 5;
            gbNivelEstud.TabStop = false;
            gbNivelEstud.Text = "¿Cuál fue el nivel de estudios más alto al que asistió?";
            // 
            // cmbEstudios
            // 
            cmbEstudios.FormattingEnabled = true;
            cmbEstudios.Items.AddRange(new object[] { "Primaria", "Secundaria", "Universidad", "Ninguno" });
            cmbEstudios.Location = new Point(99, 20);
            cmbEstudios.Name = "cmbEstudios";
            cmbEstudios.Size = new Size(121, 22);
            cmbEstudios.TabIndex = 28;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(9, 29);
            label9.Name = "label9";
            label9.Size = new Size(0, 14);
            label9.TabIndex = 4;
            // 
            // gbAlfabeta
            // 
            gbAlfabeta.Controls.Add(rbnalfabetaS);
            gbAlfabeta.Controls.Add(rbnalfabetaN);
            gbAlfabeta.Controls.Add(lbllleerescribir);
            gbAlfabeta.Location = new Point(366, 225);
            gbAlfabeta.Name = "gbAlfabeta";
            gbAlfabeta.Size = new Size(244, 56);
            gbAlfabeta.TabIndex = 20;
            gbAlfabeta.TabStop = false;
            gbAlfabeta.Text = "ALFABETA";
            // 
            // rbnalfabetaS
            // 
            rbnalfabetaS.AutoSize = true;
            rbnalfabetaS.Location = new Point(193, 24);
            rbnalfabetaS.Name = "rbnalfabetaS";
            rbnalfabetaS.Size = new Size(36, 18);
            rbnalfabetaS.TabIndex = 21;
            rbnalfabetaS.TabStop = true;
            rbnalfabetaS.Text = "Si";
            rbnalfabetaS.UseVisualStyleBackColor = true;
            // 
            // rbnalfabetaN
            // 
            rbnalfabetaN.AutoSize = true;
            rbnalfabetaN.Location = new Point(146, 24);
            rbnalfabetaN.Name = "rbnalfabetaN";
            rbnalfabetaN.Size = new Size(41, 18);
            rbnalfabetaN.TabIndex = 1;
            rbnalfabetaN.TabStop = true;
            rbnalfabetaN.Text = "No";
            rbnalfabetaN.UseVisualStyleBackColor = true;
            // 
            // lbllleerescribir
            // 
            lbllleerescribir.AutoSize = true;
            lbllleerescribir.Location = new Point(6, 24);
            lbllleerescribir.Name = "lbllleerescribir";
            lbllleerescribir.Size = new Size(134, 14);
            lbllleerescribir.TabIndex = 0;
            lbllleerescribir.Text = "¿Sabe leer y escribir?";
            // 
            // gbFecha
            // 
            gbFecha.Controls.Add(rbnAños);
            gbFecha.Controls.Add(dtpFechaN);
            gbFecha.Controls.Add(lblFechaN);
            gbFecha.Controls.Add(TxtAños);
            gbFecha.Controls.Add(lblAñosCumplidos);
            gbFecha.Location = new Point(6, 154);
            gbFecha.Name = "gbFecha";
            gbFecha.Size = new Size(666, 65);
            gbFecha.TabIndex = 19;
            gbFecha.TabStop = false;
            gbFecha.Text = "FECHA N. - EDAD";
            // 
            // rbnAños
            // 
            rbnAños.AutoSize = true;
            rbnAños.Location = new Point(614, 20);
            rbnAños.Name = "rbnAños";
            rbnAños.Size = new Size(46, 32);
            rbnAños.TabIndex = 12;
            rbnAños.TabStop = true;
            rbnAños.Text = ">35\r\n<15\r\n";
            rbnAños.UseVisualStyleBackColor = true;
            // 
            // dtpFechaN
            // 
            dtpFechaN.Format = DateTimePickerFormat.Short;
            dtpFechaN.Location = new Point(165, 28);
            dtpFechaN.Name = "dtpFechaN";
            dtpFechaN.Size = new Size(106, 21);
            dtpFechaN.TabIndex = 3;
            // 
            // lblFechaN
            // 
            lblFechaN.AutoSize = true;
            lblFechaN.Location = new Point(9, 28);
            lblFechaN.Name = "lblFechaN";
            lblFechaN.Size = new Size(128, 14);
            lblFechaN.TabIndex = 1;
            lblFechaN.Text = "Fecha de Nacimiento";
            // 
            // TxtAños
            // 
            TxtAños.Location = new Point(525, 25);
            TxtAños.MaxLength = 3;
            TxtAños.Name = "TxtAños";
            TxtAños.Size = new Size(55, 21);
            TxtAños.TabIndex = 11;
            TxtAños.TextChanged += TxtAños_TextChanged;
            // 
            // lblAñosCumplidos
            // 
            lblAñosCumplidos.AutoSize = true;
            lblAñosCumplidos.Location = new Point(324, 28);
            lblAñosCumplidos.Name = "lblAñosCumplidos";
            lblAñosCumplidos.Size = new Size(195, 14);
            lblAñosCumplidos.TabIndex = 2;
            lblAñosCumplidos.Text = "¿Cuantos años cumplidos tiene?";
            // 
            // gbEtnia
            // 
            gbEtnia.Controls.Add(lblEtniaConsidera);
            gbEtnia.Controls.Add(cmbEtnia);
            gbEtnia.Location = new Point(43, 225);
            gbEtnia.Name = "gbEtnia";
            gbEtnia.Size = new Size(305, 56);
            gbEtnia.TabIndex = 18;
            gbEtnia.TabStop = false;
            gbEtnia.Text = "ETINA";
            // 
            // lblEtniaConsidera
            // 
            lblEtniaConsidera.AutoSize = true;
            lblEtniaConsidera.Location = new Point(17, 24);
            lblEtniaConsidera.Name = "lblEtniaConsidera";
            lblEtniaConsidera.Size = new Size(133, 14);
            lblEtniaConsidera.TabIndex = 29;
            lblEtniaConsidera.Text = "¿Como se considera?";
            // 
            // cmbEtnia
            // 
            cmbEtnia.FormattingEnabled = true;
            cmbEtnia.Items.AddRange(new object[] { "Blanca", "Negra", "Indigena", "Mestiza", "Otros" });
            cmbEtnia.Location = new Point(156, 20);
            cmbEtnia.Name = "cmbEtnia";
            cmbEtnia.Size = new Size(121, 22);
            cmbEtnia.TabIndex = 28;
            // 
            // gbNombApelli
            // 
            gbNombApelli.Controls.Add(txtLocalidad);
            gbNombApelli.Controls.Add(txtApellido);
            gbNombApelli.Controls.Add(txtTelefono);
            gbNombApelli.Controls.Add(txtDirección);
            gbNombApelli.Controls.Add(loblLocalidad);
            gbNombApelli.Controls.Add(lblTeléfono);
            gbNombApelli.Controls.Add(lblDirección);
            gbNombApelli.Controls.Add(txtNombre);
            gbNombApelli.Controls.Add(lblApellido);
            gbNombApelli.Controls.Add(lblNombre);
            gbNombApelli.Location = new Point(6, 30);
            gbNombApelli.Name = "gbNombApelli";
            gbNombApelli.Size = new Size(666, 118);
            gbNombApelli.TabIndex = 0;
            gbNombApelli.TabStop = false;
            gbNombApelli.Text = "NOMBRE – APELLIDO";
            // 
            // txtLocalidad
            // 
            txtLocalidad.Location = new Point(517, 83);
            txtLocalidad.Name = "txtLocalidad";
            txtLocalidad.Size = new Size(100, 21);
            txtLocalidad.TabIndex = 12;
            txtLocalidad.TextChanged += txtLocalidad_TextChanged;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(356, 33);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(155, 21);
            txtApellido.TabIndex = 11;
            txtApellido.TextChanged += txtApellido_TextChanged;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(302, 83);
            txtTelefono.MaxLength = 10;
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(106, 21);
            txtTelefono.TabIndex = 9;
            txtTelefono.TextChanged += txtTelefono_TextChanged;
            // 
            // txtDirección
            // 
            txtDirección.Location = new Point(99, 83);
            txtDirección.Name = "txtDirección";
            txtDirección.Size = new Size(108, 21);
            txtDirección.TabIndex = 8;
            // 
            // loblLocalidad
            // 
            loblLocalidad.AutoSize = true;
            loblLocalidad.Location = new Point(438, 85);
            loblLocalidad.Name = "loblLocalidad";
            loblLocalidad.Size = new Size(64, 14);
            loblLocalidad.TabIndex = 7;
            loblLocalidad.Text = "Localidad";
            // 
            // lblTeléfono
            // 
            lblTeléfono.AutoSize = true;
            lblTeléfono.Location = new Point(229, 85);
            lblTeléfono.Name = "lblTeléfono";
            lblTeléfono.Size = new Size(57, 14);
            lblTeléfono.TabIndex = 6;
            lblTeléfono.Text = "Teléfono";
            // 
            // lblDirección
            // 
            lblDirección.AutoSize = true;
            lblDirección.Location = new Point(22, 86);
            lblDirección.Name = "lblDirección";
            lblDirección.Size = new Size(62, 14);
            lblDirección.TabIndex = 5;
            lblDirección.Text = "Direccion";
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNombre.Location = new Point(97, 36);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(156, 21);
            txtNombre.TabIndex = 3;
            txtNombre.TextChanged += txtNombre_TextChanged;
            // 
            // lblApellido
            // 
            lblApellido.AutoSize = true;
            lblApellido.Location = new Point(277, 36);
            lblApellido.Name = "lblApellido";
            lblApellido.Size = new Size(55, 14);
            lblApellido.TabIndex = 2;
            lblApellido.Text = "Apellido";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(25, 36);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(57, 14);
            lblNombre.TabIndex = 1;
            lblNombre.Text = "Nombre ";
            // 
            // btnSalir2
            // 
            btnSalir2.BackColor = Color.LightSkyBlue;
            btnSalir2.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSalir2.ForeColor = SystemColors.ControlLightLight;
            btnSalir2.Location = new Point(24, 563);
            btnSalir2.Margin = new Padding(2);
            btnSalir2.Name = "btnSalir2";
            btnSalir2.Size = new Size(132, 26);
            btnSalir2.TabIndex = 3;
            btnSalir2.Text = "CERRAR SESION";
            btnSalir2.UseVisualStyleBackColor = false;
            btnSalir2.Click += btnSalir2_Click;
            // 
            // btnRmenu
            // 
            btnRmenu.BackColor = Color.LightSkyBlue;
            btnRmenu.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRmenu.ForeColor = SystemColors.ControlLightLight;
            btnRmenu.Location = new Point(283, 562);
            btnRmenu.Margin = new Padding(2);
            btnRmenu.Name = "btnRmenu";
            btnRmenu.Size = new Size(170, 28);
            btnRmenu.TabIndex = 4;
            btnRmenu.Text = "REGRESAR AL MENÚ";
            btnRmenu.UseVisualStyleBackColor = false;
            btnRmenu.Click += btnRmenu_Click;
            // 
            // erpBoton
            // 
            erpBoton.ContainerControl = this;
            // 
            // erpListas
            // 
            erpListas.ContainerControl = this;
            // 
            // erpTexto
            // 
            erpTexto.ContainerControl = this;
            // 
            // HCPERINATAL
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(723, 601);
            Controls.Add(btnRmenu);
            Controls.Add(btnSalir2);
            Controls.Add(gbHistoriaClínicaP);
            Controls.Add(btnContnuar);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "HCPERINATAL";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "H.C. PERINATAL";
            gbHistoriaClínicaP.ResumeLayout(false);
            gbLugar.ResumeLayout(false);
            gbLugar.PerformLayout();
            gbEstadoCivil.ResumeLayout(false);
            gbEstadoCivil.PerformLayout();
            gbEstudios.ResumeLayout(false);
            gbEstudios.PerformLayout();
            gbAñoalto.ResumeLayout(false);
            gbAñoalto.PerformLayout();
            gbNivelEstud.ResumeLayout(false);
            gbAlfabeta.ResumeLayout(false);
            gbAlfabeta.PerformLayout();
            gbFecha.ResumeLayout(false);
            gbFecha.PerformLayout();
            gbEtnia.ResumeLayout(false);
            gbEtnia.PerformLayout();
            gbNombApelli.ResumeLayout(false);
            gbNombApelli.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)erpBoton).EndInit();
            ((System.ComponentModel.ISupportInitialize)erpListas).EndInit();
            ((System.ComponentModel.ISupportInitialize)erpTexto).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gbHistoriaClínicaP;
        private GroupBox gbNombApelli;
        private TextBox txtNombre;
        private Label lblApellido;
        private Label lblNombre;
        private DateTimePicker dtpFechaN;
        private Label lblAñosCumplidos;
        private Label lblFechaN;
        private TextBox txtTelefono;
        private TextBox txtDirección;
        private Label loblLocalidad;
        private Label lblTeléfono;
        private Label lblDirección;
        private TextBox TxtAños;
        private GroupBox gbFecha;
        private GroupBox gbEtnia;
        private GroupBox gbAlfabeta;
        private RadioButton rbnalfabetaS;
        private RadioButton rbnalfabetaN;
        private Label lbllleerescribir;
        private GroupBox gbEstudios;
        private GroupBox gbAñoalto;
        private GroupBox gbNivelEstud;
        private Label label9;
        private GroupBox gbLugar;
        private TextBox txtlugarcontrol;
        private GroupBox gbEstadoCivil;
        private TextBox txtnumeroidentidad;
        private TextBox txtlugarparto;
        private Label lblIdentidad;
        private Label lblLugarPA;
        private Label lblLugarCP;
        private Button btnContnuar;
        private Panel panel1;
        private ErrorProvider erpNumeros;
        private ErrorProvider erpLetras;
        private TextBox txtApellido;
        private TextBox txtLocalidad;
        private TextBox txtañosmn;
        private Button btnSalir2;
        private Button btnRmenu;
        private ErrorProvider erpBoton;
        private ComboBox cmbEtnia;
        private ComboBox cmbEstudios;
        private ComboBox cmbEstadoCivil;
        private ErrorProvider erpListas;
        private ErrorProvider erpTexto;
        private RadioButton radioButton1;
        private Label label2;
        private Label label1;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton rbnSolan;
        private RadioButton rbnSolas;
        private Label lblViveSola;
        private RadioButton rbnAños;
        private Label lblEtniaConsidera;
    }
}