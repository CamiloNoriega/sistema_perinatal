﻿namespace SISTEMA_INFORMATICO_PERINATAL
{
    partial class ANTECEDENTES
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ANTECEDENTES));
            gbantecedentesF = new GroupBox();
            gbAntecedentesO = new GroupBox();
            gbVC = new GroupBox();
            lblPartos = new Label();
            txtpartos = new TextBox();
            lblVaginales = new Label();
            txtvaginales = new TextBox();
            lblCesáreas = new Label();
            txtcesareas = new TextBox();
            gbAbortos = new GroupBox();
            rbn3ExpontConse = new RadioButton();
            txtabortos = new TextBox();
            lblabortos = new Label();
            gbfracasoMA = new GroupBox();
            lblMetodoA = new Label();
            rbnfracasoMAna = new RadioButton();
            rbnfracasoMAe = new RadioButton();
            rbnfracasoMAh = new RadioButton();
            rbnfracasoMAdiu = new RadioButton();
            rbnfracasoMAb = new RadioButton();
            rbnfracasoMAn = new RadioButton();
            gbembarazoplaneado = new GroupBox();
            lblEmbarazoP = new Label();
            rbnembplaneN = new RadioButton();
            rbnembplaneS = new RadioButton();
            gbEmbarazoAnterior = new GroupBox();
            rbnMenos1A = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            gbAntecedentesDG = new GroupBox();
            rbnAntecedentesDGn = new RadioButton();
            rbnAntecedentesDGs = new RadioButton();
            lblNacidosMuertos = new Label();
            txtnacidosmuertos = new TextBox();
            lblNacidosVivos = new Label();
            txtviven = new TextBox();
            txtmuertos = new TextBox();
            txtnvivos = new TextBox();
            gbUltimoPrevio = new GroupBox();
            rbnultprevnormal = new RadioButton();
            rbnultprev4000g = new RadioButton();
            rbnultprev2500g = new RadioButton();
            rbnultprevnc = new RadioButton();
            lblVive = new Label();
            lblMuertos1SEM = new Label();
            txtetopico = new TextBox();
            lblGestasPrevios = new Label();
            lblEmbaÉtopico = new Label();
            txtgestas = new TextBox();
            groupBox4 = new GroupBox();
            gbfamiliares = new GroupBox();
            gbOtraCondf = new GroupBox();
            rbnOtraCondFn = new RadioButton();
            rbnOtraCondFs = new RadioButton();
            gbEclampsiaf = new GroupBox();
            rbnEclampsiaFn = new RadioButton();
            rbnEclampsiaFs = new RadioButton();
            gbPreeclmpsiaf = new GroupBox();
            rbnpreeclampsiaFn = new RadioButton();
            rbnPreeclampsiaFs = new RadioButton();
            gbTBCf = new GroupBox();
            rbnTBCFn = new RadioButton();
            rbnTBCFs = new RadioButton();
            gbDiabtesf = new GroupBox();
            rbndiabetesFn = new RadioButton();
            rbndiabetesFs = new RadioButton();
            gbHipertensiónf = new GroupBox();
            rbnhipertensionFn = new RadioButton();
            rbnHipertensionFs = new RadioButton();
            lblfamiliaresN = new Label();
            lblfamiliaresS = new Label();
            gbpersonales = new GroupBox();
            gbDiabetesp = new GroupBox();
            rbnDiabetesPn = new RadioButton();
            rbnDiabetesP1 = new RadioButton();
            rbnDiabetesP2 = new RadioButton();
            rbnDiabetesP3 = new RadioButton();
            gbVIH = new GroupBox();
            rbnVIHN = new RadioButton();
            rbnVIHS = new RadioButton();
            gbViolencia = new GroupBox();
            rbnViolenciaN = new RadioButton();
            rbnViolenciaS = new RadioButton();
            gbNefropatía = new GroupBox();
            rbnNefropatíaN = new RadioButton();
            rbnNefropatíaS = new RadioButton();
            gbCirugíaG = new GroupBox();
            rbnCirugiagN = new RadioButton();
            rbnCirugíagS = new RadioButton();
            gbInfertilidad = new GroupBox();
            rbnInfertilidadN = new RadioButton();
            rbnInfertilidadS = new RadioButton();
            gbCardiopatía = new GroupBox();
            rbnCardiopatíaN = new RadioButton();
            rbnCardipatíaS = new RadioButton();
            lblpersonalesN2 = new Label();
            lblpersonalesS2 = new Label();
            gbOtraCondp = new GroupBox();
            rbnOtraCondPn = new RadioButton();
            rbnOtraCondPs = new RadioButton();
            lblVIH = new Label();
            gbEclampsiap = new GroupBox();
            rbnEclampsiaPn = new RadioButton();
            rbnEclampsiaPs = new RadioButton();
            lblViolencia = new Label();
            gbPreeclampsiap = new GroupBox();
            rbnPreeclampsiaPn = new RadioButton();
            rbnPreeclampsiaPs = new RadioButton();
            lblNefropatía = new Label();
            gbTBCp = new GroupBox();
            rbnTBCPn = new RadioButton();
            rbnTBCPs = new RadioButton();
            lblCardipatía = new Label();
            gbHipertensiónp = new GroupBox();
            rbnHipertensiónPn = new RadioButton();
            rbnHipertensiónPs = new RadioButton();
            lblInfertilidad = new Label();
            lblpersonalesN1 = new Label();
            lblCirugíag = new Label();
            lblpersonalesS1 = new Label();
            lblEclampsia = new Label();
            lblTBC = new Label();
            lblPreeclampsia = new Label();
            lblDiabetes = new Label();
            lblOtraCond = new Label();
            lblHipertensión = new Label();
            btnContnuar2 = new Button();
            erpNumeros = new ErrorProvider(components);
            btnRmenu = new Button();
            btnSalir3 = new Button();
            erpBoton = new ErrorProvider(components);
            gbantecedentesF.SuspendLayout();
            gbAntecedentesO.SuspendLayout();
            gbVC.SuspendLayout();
            gbAbortos.SuspendLayout();
            gbfracasoMA.SuspendLayout();
            gbembarazoplaneado.SuspendLayout();
            gbEmbarazoAnterior.SuspendLayout();
            gbAntecedentesDG.SuspendLayout();
            gbUltimoPrevio.SuspendLayout();
            groupBox4.SuspendLayout();
            gbfamiliares.SuspendLayout();
            gbOtraCondf.SuspendLayout();
            gbEclampsiaf.SuspendLayout();
            gbPreeclmpsiaf.SuspendLayout();
            gbTBCf.SuspendLayout();
            gbDiabtesf.SuspendLayout();
            gbHipertensiónf.SuspendLayout();
            gbpersonales.SuspendLayout();
            gbDiabetesp.SuspendLayout();
            gbVIH.SuspendLayout();
            gbViolencia.SuspendLayout();
            gbNefropatía.SuspendLayout();
            gbCirugíaG.SuspendLayout();
            gbInfertilidad.SuspendLayout();
            gbCardiopatía.SuspendLayout();
            gbOtraCondp.SuspendLayout();
            gbEclampsiap.SuspendLayout();
            gbPreeclampsiap.SuspendLayout();
            gbTBCp.SuspendLayout();
            gbHipertensiónp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)erpNumeros).BeginInit();
            ((System.ComponentModel.ISupportInitialize)erpBoton).BeginInit();
            SuspendLayout();
            // 
            // gbantecedentesF
            // 
            gbantecedentesF.BackColor = SystemColors.GradientInactiveCaption;
            gbantecedentesF.Controls.Add(gbAntecedentesO);
            gbantecedentesF.Controls.Add(groupBox4);
            gbantecedentesF.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbantecedentesF.ForeColor = SystemColors.ActiveCaptionText;
            gbantecedentesF.Location = new Point(12, 12);
            gbantecedentesF.Name = "gbantecedentesF";
            gbantecedentesF.Size = new Size(949, 661);
            gbantecedentesF.TabIndex = 0;
            gbantecedentesF.TabStop = false;
            gbantecedentesF.Text = "ANTECEDENTES FAMILIARES, PERSONALES Y OBSTÉTRICOS";
            // 
            // gbAntecedentesO
            // 
            gbAntecedentesO.Controls.Add(gbVC);
            gbAntecedentesO.Controls.Add(gbAbortos);
            gbAntecedentesO.Controls.Add(gbfracasoMA);
            gbAntecedentesO.Controls.Add(gbembarazoplaneado);
            gbAntecedentesO.Controls.Add(gbEmbarazoAnterior);
            gbAntecedentesO.Controls.Add(gbAntecedentesDG);
            gbAntecedentesO.Controls.Add(lblNacidosMuertos);
            gbAntecedentesO.Controls.Add(txtnacidosmuertos);
            gbAntecedentesO.Controls.Add(lblNacidosVivos);
            gbAntecedentesO.Controls.Add(txtviven);
            gbAntecedentesO.Controls.Add(txtmuertos);
            gbAntecedentesO.Controls.Add(txtnvivos);
            gbAntecedentesO.Controls.Add(gbUltimoPrevio);
            gbAntecedentesO.Controls.Add(lblVive);
            gbAntecedentesO.Controls.Add(lblMuertos1SEM);
            gbAntecedentesO.Controls.Add(txtetopico);
            gbAntecedentesO.Controls.Add(lblGestasPrevios);
            gbAntecedentesO.Controls.Add(lblEmbaÉtopico);
            gbAntecedentesO.Controls.Add(txtgestas);
            gbAntecedentesO.Location = new Point(6, 373);
            gbAntecedentesO.Name = "gbAntecedentesO";
            gbAntecedentesO.Size = new Size(917, 278);
            gbAntecedentesO.TabIndex = 16;
            gbAntecedentesO.TabStop = false;
            gbAntecedentesO.Text = "ANTECEDENTES OBSTETRICOS";
            // 
            // gbVC
            // 
            gbVC.Controls.Add(lblPartos);
            gbVC.Controls.Add(txtpartos);
            gbVC.Controls.Add(lblVaginales);
            gbVC.Controls.Add(txtvaginales);
            gbVC.Controls.Add(lblCesáreas);
            gbVC.Controls.Add(txtcesareas);
            gbVC.Location = new Point(170, 20);
            gbVC.Name = "gbVC";
            gbVC.Size = new Size(202, 112);
            gbVC.TabIndex = 29;
            gbVC.TabStop = false;
            gbVC.Text = "PARTOS / VAGINALES - CESÁREAS";
            // 
            // lblPartos
            // 
            lblPartos.AutoSize = true;
            lblPartos.Location = new Point(20, 33);
            lblPartos.Name = "lblPartos";
            lblPartos.Size = new Size(112, 14);
            lblPartos.TabIndex = 10;
            lblPartos.Text = "Numero de partos";
            // 
            // txtpartos
            // 
            txtpartos.Location = new Point(138, 30);
            txtpartos.MaxLength = 2;
            txtpartos.Name = "txtpartos";
            txtpartos.Size = new Size(33, 21);
            txtpartos.TabIndex = 11;
            txtpartos.TextChanged += txtpartos_TextChanged;
            // 
            // lblVaginales
            // 
            lblVaginales.AutoSize = true;
            lblVaginales.Location = new Point(15, 61);
            lblVaginales.Name = "lblVaginales";
            lblVaginales.Size = new Size(117, 14);
            lblVaginales.TabIndex = 8;
            lblVaginales.Text = "Cuantos  vaginales";
            // 
            // txtvaginales
            // 
            txtvaginales.Location = new Point(138, 58);
            txtvaginales.MaxLength = 2;
            txtvaginales.Name = "txtvaginales";
            txtvaginales.Size = new Size(33, 21);
            txtvaginales.TabIndex = 9;
            txtvaginales.TextChanged += txtvaginales_TextChanged;
            // 
            // lblCesáreas
            // 
            lblCesáreas.AutoSize = true;
            lblCesáreas.Location = new Point(7, 86);
            lblCesáreas.Name = "lblCesáreas";
            lblCesáreas.Size = new Size(128, 14);
            lblCesáreas.TabIndex = 12;
            lblCesáreas.Text = "Cuantos por cesarea";
            // 
            // txtcesareas
            // 
            txtcesareas.Location = new Point(137, 83);
            txtcesareas.MaxLength = 2;
            txtcesareas.Name = "txtcesareas";
            txtcesareas.Size = new Size(33, 21);
            txtcesareas.TabIndex = 13;
            txtcesareas.TextChanged += txtcesareas_TextChanged;
            // 
            // gbAbortos
            // 
            gbAbortos.Controls.Add(rbn3ExpontConse);
            gbAbortos.Controls.Add(txtabortos);
            gbAbortos.Controls.Add(lblabortos);
            gbAbortos.Location = new Point(583, 46);
            gbAbortos.Name = "gbAbortos";
            gbAbortos.Size = new Size(294, 61);
            gbAbortos.TabIndex = 28;
            gbAbortos.TabStop = false;
            // 
            // rbn3ExpontConse
            // 
            rbn3ExpontConse.AutoSize = true;
            rbn3ExpontConse.Location = new Point(127, 26);
            rbn3ExpontConse.Margin = new Padding(2);
            rbn3ExpontConse.Name = "rbn3ExpontConse";
            rbn3ExpontConse.Size = new Size(158, 18);
            rbn3ExpontConse.TabIndex = 8;
            rbn3ExpontConse.TabStop = true;
            rbn3ExpontConse.Text = "3 expont. consecutivos";
            rbn3ExpontConse.UseVisualStyleBackColor = true;
            // 
            // txtabortos
            // 
            txtabortos.Location = new Point(65, 22);
            txtabortos.MaxLength = 2;
            txtabortos.Name = "txtabortos";
            txtabortos.Size = new Size(40, 21);
            txtabortos.TabIndex = 7;
            txtabortos.TextChanged += txtabortos_TextChanged;
            // 
            // lblabortos
            // 
            lblabortos.AutoSize = true;
            lblabortos.Location = new Point(11, 27);
            lblabortos.Name = "lblabortos";
            lblabortos.Size = new Size(54, 14);
            lblabortos.TabIndex = 6;
            lblabortos.Text = "Abortos";
            // 
            // gbfracasoMA
            // 
            gbfracasoMA.Controls.Add(lblMetodoA);
            gbfracasoMA.Controls.Add(rbnfracasoMAna);
            gbfracasoMA.Controls.Add(rbnfracasoMAe);
            gbfracasoMA.Controls.Add(rbnfracasoMAh);
            gbfracasoMA.Controls.Add(rbnfracasoMAdiu);
            gbfracasoMA.Controls.Add(rbnfracasoMAb);
            gbfracasoMA.Controls.Add(rbnfracasoMAn);
            gbfracasoMA.Location = new Point(237, 192);
            gbfracasoMA.Name = "gbfracasoMA";
            gbfracasoMA.Size = new Size(451, 73);
            gbfracasoMA.TabIndex = 27;
            gbfracasoMA.TabStop = false;
            gbfracasoMA.Text = "FRACASO MÉTODO ANTICONCEPTIVOS";
            // 
            // lblMetodoA
            // 
            lblMetodoA.AutoSize = true;
            lblMetodoA.Location = new Point(6, 21);
            lblMetodoA.Name = "lblMetodoA";
            lblMetodoA.Size = new Size(135, 42);
            lblMetodoA.TabIndex = 31;
            lblMetodoA.Text = "¿estaba usando algún\r\nmétodo para evitar\r\nel embarazo?";
            // 
            // rbnfracasoMAna
            // 
            rbnfracasoMAna.AutoSize = true;
            rbnfracasoMAna.Location = new Point(343, 45);
            rbnfracasoMAna.Name = "rbnfracasoMAna";
            rbnfracasoMAna.Size = new Size(67, 18);
            rbnfracasoMAna.TabIndex = 3;
            rbnfracasoMAna.TabStop = true;
            rbnfracasoMAna.Text = "Natural";
            rbnfracasoMAna.UseVisualStyleBackColor = true;
            // 
            // rbnfracasoMAe
            // 
            rbnfracasoMAe.AutoSize = true;
            rbnfracasoMAe.Location = new Point(342, 20);
            rbnfracasoMAe.Name = "rbnfracasoMAe";
            rbnfracasoMAe.Size = new Size(95, 18);
            rbnfracasoMAe.TabIndex = 2;
            rbnfracasoMAe.TabStop = true;
            rbnfracasoMAe.Text = "Emergencia";
            rbnfracasoMAe.UseVisualStyleBackColor = true;
            // 
            // rbnfracasoMAh
            // 
            rbnfracasoMAh.AutoSize = true;
            rbnfracasoMAh.Location = new Point(162, 47);
            rbnfracasoMAh.Name = "rbnfracasoMAh";
            rbnfracasoMAh.Size = new Size(81, 18);
            rbnfracasoMAh.TabIndex = 2;
            rbnfracasoMAh.TabStop = true;
            rbnfracasoMAh.Text = "Hormonal";
            rbnfracasoMAh.UseVisualStyleBackColor = true;
            // 
            // rbnfracasoMAdiu
            // 
            rbnfracasoMAdiu.AutoSize = true;
            rbnfracasoMAdiu.Location = new Point(259, 47);
            rbnfracasoMAdiu.Name = "rbnfracasoMAdiu";
            rbnfracasoMAdiu.Size = new Size(47, 18);
            rbnfracasoMAdiu.TabIndex = 1;
            rbnfracasoMAdiu.TabStop = true;
            rbnfracasoMAdiu.Text = "DIU";
            rbnfracasoMAdiu.UseVisualStyleBackColor = true;
            // 
            // rbnfracasoMAb
            // 
            rbnfracasoMAb.AutoSize = true;
            rbnfracasoMAb.Location = new Point(259, 20);
            rbnfracasoMAb.Name = "rbnfracasoMAb";
            rbnfracasoMAb.Size = new Size(70, 18);
            rbnfracasoMAb.TabIndex = 1;
            rbnfracasoMAb.TabStop = true;
            rbnfracasoMAb.Text = "Barrera";
            rbnfracasoMAb.UseVisualStyleBackColor = true;
            // 
            // rbnfracasoMAn
            // 
            rbnfracasoMAn.AutoSize = true;
            rbnfracasoMAn.Location = new Point(162, 20);
            rbnfracasoMAn.Name = "rbnfracasoMAn";
            rbnfracasoMAn.Size = new Size(80, 18);
            rbnfracasoMAn.TabIndex = 0;
            rbnfracasoMAn.TabStop = true;
            rbnfracasoMAn.Text = "No usaba";
            rbnfracasoMAn.UseVisualStyleBackColor = true;
            // 
            // gbembarazoplaneado
            // 
            gbembarazoplaneado.Controls.Add(lblEmbarazoP);
            gbembarazoplaneado.Controls.Add(rbnembplaneN);
            gbembarazoplaneado.Controls.Add(rbnembplaneS);
            gbembarazoplaneado.Location = new Point(9, 192);
            gbembarazoplaneado.Name = "gbembarazoplaneado";
            gbembarazoplaneado.Size = new Size(210, 73);
            gbembarazoplaneado.TabIndex = 26;
            gbembarazoplaneado.TabStop = false;
            gbembarazoplaneado.Text = "EMBARAZO PLANEADO";
            // 
            // lblEmbarazoP
            // 
            lblEmbarazoP.AutoSize = true;
            lblEmbarazoP.Location = new Point(6, 24);
            lblEmbarazoP.Name = "lblEmbarazoP";
            lblEmbarazoP.Size = new Size(103, 28);
            lblEmbarazoP.TabIndex = 30;
            lblEmbarazoP.Text = "¿No quería tener\r\n (más) hijos?";
            // 
            // rbnembplaneN
            // 
            rbnembplaneN.AutoSize = true;
            rbnembplaneN.Location = new Point(156, 35);
            rbnembplaneN.Name = "rbnembplaneN";
            rbnembplaneN.Size = new Size(41, 18);
            rbnembplaneN.TabIndex = 1;
            rbnembplaneN.TabStop = true;
            rbnembplaneN.Text = "No";
            rbnembplaneN.UseVisualStyleBackColor = true;
            // 
            // rbnembplaneS
            // 
            rbnembplaneS.AutoSize = true;
            rbnembplaneS.Location = new Point(114, 34);
            rbnembplaneS.Name = "rbnembplaneS";
            rbnembplaneS.Size = new Size(36, 18);
            rbnembplaneS.TabIndex = 0;
            rbnembplaneS.TabStop = true;
            rbnembplaneS.Text = "Si";
            rbnembplaneS.UseVisualStyleBackColor = true;
            // 
            // gbEmbarazoAnterior
            // 
            gbEmbarazoAnterior.Controls.Add(rbnMenos1A);
            gbEmbarazoAnterior.Controls.Add(dateTimePicker1);
            gbEmbarazoAnterior.Location = new Point(650, 113);
            gbEmbarazoAnterior.Name = "gbEmbarazoAnterior";
            gbEmbarazoAnterior.Size = new Size(227, 73);
            gbEmbarazoAnterior.TabIndex = 25;
            gbEmbarazoAnterior.TabStop = false;
            gbEmbarazoAnterior.Text = "FIN EMBARAZO ANTERIOR";
            // 
            // rbnMenos1A
            // 
            rbnMenos1A.AutoSize = true;
            rbnMenos1A.Location = new Point(121, 29);
            rbnMenos1A.Name = "rbnMenos1A";
            rbnMenos1A.Size = new Size(97, 18);
            rbnMenos1A.TabIndex = 1;
            rbnMenos1A.TabStop = true;
            rbnMenos1A.Text = "Menos 1 año";
            rbnMenos1A.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Location = new Point(13, 28);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(89, 21);
            dateTimePicker1.TabIndex = 0;
            // 
            // gbAntecedentesDG
            // 
            gbAntecedentesDG.Controls.Add(rbnAntecedentesDGn);
            gbAntecedentesDG.Controls.Add(rbnAntecedentesDGs);
            gbAntecedentesDG.Location = new Point(710, 193);
            gbAntecedentesDG.Name = "gbAntecedentesDG";
            gbAntecedentesDG.Size = new Size(176, 71);
            gbAntecedentesDG.TabIndex = 1;
            gbAntecedentesDG.TabStop = false;
            gbAntecedentesDG.Text = "ANTECESDENTES DE GEMELARES";
            // 
            // rbnAntecedentesDGn
            // 
            rbnAntecedentesDGn.AutoSize = true;
            rbnAntecedentesDGn.Location = new Point(96, 32);
            rbnAntecedentesDGn.Name = "rbnAntecedentesDGn";
            rbnAntecedentesDGn.Size = new Size(41, 18);
            rbnAntecedentesDGn.TabIndex = 1;
            rbnAntecedentesDGn.TabStop = true;
            rbnAntecedentesDGn.Text = "No";
            rbnAntecedentesDGn.UseVisualStyleBackColor = true;
            // 
            // rbnAntecedentesDGs
            // 
            rbnAntecedentesDGs.AutoSize = true;
            rbnAntecedentesDGs.Location = new Point(26, 32);
            rbnAntecedentesDGs.Name = "rbnAntecedentesDGs";
            rbnAntecedentesDGs.Size = new Size(36, 18);
            rbnAntecedentesDGs.TabIndex = 0;
            rbnAntecedentesDGs.TabStop = true;
            rbnAntecedentesDGs.Text = "Si";
            rbnAntecedentesDGs.UseVisualStyleBackColor = true;
            // 
            // lblNacidosMuertos
            // 
            lblNacidosMuertos.AutoSize = true;
            lblNacidosMuertos.Location = new Point(5, 133);
            lblNacidosMuertos.Name = "lblNacidosMuertos";
            lblNacidosMuertos.Size = new Size(106, 14);
            lblNacidosMuertos.TabIndex = 16;
            lblNacidosMuertos.Text = "Nacidos muertos";
            // 
            // txtnacidosmuertos
            // 
            txtnacidosmuertos.Location = new Point(121, 130);
            txtnacidosmuertos.MaxLength = 2;
            txtnacidosmuertos.Name = "txtnacidosmuertos";
            txtnacidosmuertos.Size = new Size(34, 21);
            txtnacidosmuertos.TabIndex = 17;
            txtnacidosmuertos.TextChanged += txtnacidosmuertos_TextChanged;
            // 
            // lblNacidosVivos
            // 
            lblNacidosVivos.AutoSize = true;
            lblNacidosVivos.Location = new Point(22, 79);
            lblNacidosVivos.Name = "lblNacidosVivos";
            lblNacidosVivos.Size = new Size(89, 14);
            lblNacidosVivos.TabIndex = 14;
            lblNacidosVivos.Text = "Nacidos vivos";
            // 
            // txtviven
            // 
            txtviven.Location = new Point(383, 145);
            txtviven.MaxLength = 2;
            txtviven.Name = "txtviven";
            txtviven.Size = new Size(33, 21);
            txtviven.TabIndex = 19;
            txtviven.TextChanged += txtviven_TextChanged;
            // 
            // txtmuertos
            // 
            txtmuertos.Location = new Point(588, 145);
            txtmuertos.MaxLength = 2;
            txtmuertos.Name = "txtmuertos";
            txtmuertos.Size = new Size(35, 21);
            txtmuertos.TabIndex = 21;
            txtmuertos.TextChanged += txtmuertos_TextChanged;
            // 
            // txtnvivos
            // 
            txtnvivos.Location = new Point(121, 76);
            txtnvivos.MaxLength = 2;
            txtnvivos.Name = "txtnvivos";
            txtnvivos.Size = new Size(34, 21);
            txtnvivos.TabIndex = 15;
            txtnvivos.TextChanged += txtnvivos_TextChanged;
            // 
            // gbUltimoPrevio
            // 
            gbUltimoPrevio.Controls.Add(rbnultprevnormal);
            gbUltimoPrevio.Controls.Add(rbnultprev4000g);
            gbUltimoPrevio.Controls.Add(rbnultprev2500g);
            gbUltimoPrevio.Controls.Add(rbnultprevnc);
            gbUltimoPrevio.Location = new Point(378, 25);
            gbUltimoPrevio.Name = "gbUltimoPrevio";
            gbUltimoPrevio.Size = new Size(181, 102);
            gbUltimoPrevio.TabIndex = 0;
            gbUltimoPrevio.TabStop = false;
            gbUltimoPrevio.Text = "PESO DECIEN NACIDO (ÚLTIMO PREVIO)";
            // 
            // rbnultprevnormal
            // 
            rbnultprevnormal.AutoSize = true;
            rbnultprevnormal.Location = new Point(87, 70);
            rbnultprevnormal.Name = "rbnultprevnormal";
            rbnultprevnormal.Size = new Size(67, 18);
            rbnultprevnormal.TabIndex = 3;
            rbnultprevnormal.TabStop = true;
            rbnultprevnormal.Text = "Normal";
            rbnultprevnormal.UseVisualStyleBackColor = true;
            // 
            // rbnultprev4000g
            // 
            rbnultprev4000g.AutoSize = true;
            rbnultprev4000g.Location = new Point(24, 71);
            rbnultprev4000g.Name = "rbnultprev4000g";
            rbnultprev4000g.Size = new Size(61, 18);
            rbnultprev4000g.TabIndex = 2;
            rbnultprev4000g.TabStop = true;
            rbnultprev4000g.Text = "4000g";
            rbnultprev4000g.UseVisualStyleBackColor = true;
            // 
            // rbnultprev2500g
            // 
            rbnultprev2500g.AutoSize = true;
            rbnultprev2500g.Location = new Point(85, 47);
            rbnultprev2500g.Name = "rbnultprev2500g";
            rbnultprev2500g.Size = new Size(71, 18);
            rbnultprev2500g.TabIndex = 1;
            rbnultprev2500g.TabStop = true;
            rbnultprev2500g.Text = "< 2500g";
            rbnultprev2500g.UseVisualStyleBackColor = true;
            // 
            // rbnultprevnc
            // 
            rbnultprevnc.AutoSize = true;
            rbnultprevnc.Location = new Point(24, 47);
            rbnultprevnc.Name = "rbnultprevnc";
            rbnultprevnc.Size = new Size(42, 18);
            rbnultprevnc.TabIndex = 0;
            rbnultprevnc.TabStop = true;
            rbnultprevnc.Text = "n/c";
            rbnultprevnc.UseVisualStyleBackColor = true;
            // 
            // lblVive
            // 
            lblVive.AutoSize = true;
            lblVive.Location = new Point(340, 148);
            lblVive.Name = "lblVive";
            lblVive.Size = new Size(39, 14);
            lblVive.TabIndex = 18;
            lblVive.Text = "Viven";
            // 
            // lblMuertos1SEM
            // 
            lblMuertos1SEM.AutoSize = true;
            lblMuertos1SEM.Location = new Point(450, 148);
            lblMuertos1SEM.Name = "lblMuertos1SEM";
            lblMuertos1SEM.Size = new Size(132, 14);
            lblMuertos1SEM.TabIndex = 20;
            lblMuertos1SEM.Text = "Muertos 1ra SEMANA";
            // 
            // txtetopico
            // 
            txtetopico.Location = new Point(261, 145);
            txtetopico.MaxLength = 2;
            txtetopico.Name = "txtetopico";
            txtetopico.Size = new Size(37, 21);
            txtetopico.TabIndex = 5;
            txtetopico.TextChanged += txtetopico_TextChanged;
            // 
            // lblGestasPrevios
            // 
            lblGestasPrevios.AutoSize = true;
            lblGestasPrevios.Location = new Point(15, 25);
            lblGestasPrevios.Name = "lblGestasPrevios";
            lblGestasPrevios.Size = new Size(96, 14);
            lblGestasPrevios.TabIndex = 2;
            lblGestasPrevios.Text = "Gestas previas";
            // 
            // lblEmbaÉtopico
            // 
            lblEmbaÉtopico.AutoSize = true;
            lblEmbaÉtopico.Location = new Point(170, 148);
            lblEmbaÉtopico.Name = "lblEmbaÉtopico";
            lblEmbaÉtopico.Size = new Size(85, 14);
            lblEmbaÉtopico.TabIndex = 4;
            lblEmbaÉtopico.Text = "Emb. Etópico";
            // 
            // txtgestas
            // 
            txtgestas.Location = new Point(121, 22);
            txtgestas.MaxLength = 2;
            txtgestas.Name = "txtgestas";
            txtgestas.Size = new Size(34, 21);
            txtgestas.TabIndex = 3;
            txtgestas.TextChanged += txtgestas_TextChanged;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(gbfamiliares);
            groupBox4.Controls.Add(gbpersonales);
            groupBox4.Controls.Add(lblEclampsia);
            groupBox4.Controls.Add(lblTBC);
            groupBox4.Controls.Add(lblPreeclampsia);
            groupBox4.Controls.Add(lblDiabetes);
            groupBox4.Controls.Add(lblOtraCond);
            groupBox4.Controls.Add(lblHipertensión);
            groupBox4.Location = new Point(6, 35);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(917, 332);
            groupBox4.TabIndex = 15;
            groupBox4.TabStop = false;
            groupBox4.Text = "ANTECEDENTES";
            // 
            // gbfamiliares
            // 
            gbfamiliares.Controls.Add(gbOtraCondf);
            gbfamiliares.Controls.Add(gbEclampsiaf);
            gbfamiliares.Controls.Add(gbPreeclmpsiaf);
            gbfamiliares.Controls.Add(gbTBCf);
            gbfamiliares.Controls.Add(gbDiabtesf);
            gbfamiliares.Controls.Add(gbHipertensiónf);
            gbfamiliares.Controls.Add(lblfamiliaresN);
            gbfamiliares.Controls.Add(lblfamiliaresS);
            gbfamiliares.Location = new Point(15, 22);
            gbfamiliares.Name = "gbfamiliares";
            gbfamiliares.Size = new Size(123, 294);
            gbfamiliares.TabIndex = 14;
            gbfamiliares.TabStop = false;
            gbfamiliares.Text = "FAMILIARS";
            // 
            // gbOtraCondf
            // 
            gbOtraCondf.Controls.Add(rbnOtraCondFn);
            gbOtraCondf.Controls.Add(rbnOtraCondFs);
            gbOtraCondf.Location = new Point(20, 245);
            gbOtraCondf.Name = "gbOtraCondf";
            gbOtraCondf.Size = new Size(69, 36);
            gbOtraCondf.TabIndex = 43;
            gbOtraCondf.TabStop = false;
            // 
            // rbnOtraCondFn
            // 
            rbnOtraCondFn.AutoSize = true;
            rbnOtraCondFn.Location = new Point(6, 17);
            rbnOtraCondFn.Name = "rbnOtraCondFn";
            rbnOtraCondFn.Size = new Size(14, 13);
            rbnOtraCondFn.TabIndex = 2;
            rbnOtraCondFn.TabStop = true;
            rbnOtraCondFn.UseVisualStyleBackColor = true;
            // 
            // rbnOtraCondFs
            // 
            rbnOtraCondFs.AutoSize = true;
            rbnOtraCondFs.Location = new Point(49, 17);
            rbnOtraCondFs.Name = "rbnOtraCondFs";
            rbnOtraCondFs.Size = new Size(14, 13);
            rbnOtraCondFs.TabIndex = 18;
            rbnOtraCondFs.TabStop = true;
            rbnOtraCondFs.UseVisualStyleBackColor = true;
            // 
            // gbEclampsiaf
            // 
            gbEclampsiaf.Controls.Add(rbnEclampsiaFn);
            gbEclampsiaf.Controls.Add(rbnEclampsiaFs);
            gbEclampsiaf.Location = new Point(20, 203);
            gbEclampsiaf.Name = "gbEclampsiaf";
            gbEclampsiaf.Size = new Size(69, 36);
            gbEclampsiaf.TabIndex = 44;
            gbEclampsiaf.TabStop = false;
            // 
            // rbnEclampsiaFn
            // 
            rbnEclampsiaFn.AutoSize = true;
            rbnEclampsiaFn.Location = new Point(6, 17);
            rbnEclampsiaFn.Name = "rbnEclampsiaFn";
            rbnEclampsiaFn.Size = new Size(14, 13);
            rbnEclampsiaFn.TabIndex = 2;
            rbnEclampsiaFn.TabStop = true;
            rbnEclampsiaFn.UseVisualStyleBackColor = true;
            // 
            // rbnEclampsiaFs
            // 
            rbnEclampsiaFs.AutoSize = true;
            rbnEclampsiaFs.Location = new Point(49, 17);
            rbnEclampsiaFs.Name = "rbnEclampsiaFs";
            rbnEclampsiaFs.Size = new Size(14, 13);
            rbnEclampsiaFs.TabIndex = 18;
            rbnEclampsiaFs.TabStop = true;
            rbnEclampsiaFs.UseVisualStyleBackColor = true;
            // 
            // gbPreeclmpsiaf
            // 
            gbPreeclmpsiaf.Controls.Add(rbnpreeclampsiaFn);
            gbPreeclmpsiaf.Controls.Add(rbnPreeclampsiaFs);
            gbPreeclmpsiaf.Location = new Point(20, 161);
            gbPreeclmpsiaf.Name = "gbPreeclmpsiaf";
            gbPreeclmpsiaf.Size = new Size(69, 36);
            gbPreeclmpsiaf.TabIndex = 45;
            gbPreeclmpsiaf.TabStop = false;
            // 
            // rbnpreeclampsiaFn
            // 
            rbnpreeclampsiaFn.AutoSize = true;
            rbnpreeclampsiaFn.Location = new Point(6, 17);
            rbnpreeclampsiaFn.Name = "rbnpreeclampsiaFn";
            rbnpreeclampsiaFn.Size = new Size(14, 13);
            rbnpreeclampsiaFn.TabIndex = 2;
            rbnpreeclampsiaFn.TabStop = true;
            rbnpreeclampsiaFn.UseVisualStyleBackColor = true;
            // 
            // rbnPreeclampsiaFs
            // 
            rbnPreeclampsiaFs.AutoSize = true;
            rbnPreeclampsiaFs.Location = new Point(49, 17);
            rbnPreeclampsiaFs.Name = "rbnPreeclampsiaFs";
            rbnPreeclampsiaFs.Size = new Size(14, 13);
            rbnPreeclampsiaFs.TabIndex = 18;
            rbnPreeclampsiaFs.TabStop = true;
            rbnPreeclampsiaFs.UseVisualStyleBackColor = true;
            // 
            // gbTBCf
            // 
            gbTBCf.Controls.Add(rbnTBCFn);
            gbTBCf.Controls.Add(rbnTBCFs);
            gbTBCf.Location = new Point(20, 37);
            gbTBCf.Name = "gbTBCf";
            gbTBCf.Size = new Size(69, 36);
            gbTBCf.TabIndex = 42;
            gbTBCf.TabStop = false;
            // 
            // rbnTBCFn
            // 
            rbnTBCFn.AutoSize = true;
            rbnTBCFn.Location = new Point(6, 17);
            rbnTBCFn.Name = "rbnTBCFn";
            rbnTBCFn.Size = new Size(14, 13);
            rbnTBCFn.TabIndex = 2;
            rbnTBCFn.TabStop = true;
            rbnTBCFn.UseVisualStyleBackColor = true;
            // 
            // rbnTBCFs
            // 
            rbnTBCFs.AutoSize = true;
            rbnTBCFs.Location = new Point(49, 17);
            rbnTBCFs.Name = "rbnTBCFs";
            rbnTBCFs.Size = new Size(14, 13);
            rbnTBCFs.TabIndex = 18;
            rbnTBCFs.TabStop = true;
            rbnTBCFs.UseVisualStyleBackColor = true;
            // 
            // gbDiabtesf
            // 
            gbDiabtesf.Controls.Add(rbndiabetesFn);
            gbDiabtesf.Controls.Add(rbndiabetesFs);
            gbDiabtesf.Location = new Point(20, 79);
            gbDiabtesf.Name = "gbDiabtesf";
            gbDiabtesf.Size = new Size(69, 36);
            gbDiabtesf.TabIndex = 46;
            gbDiabtesf.TabStop = false;
            // 
            // rbndiabetesFn
            // 
            rbndiabetesFn.AutoSize = true;
            rbndiabetesFn.Location = new Point(6, 17);
            rbndiabetesFn.Name = "rbndiabetesFn";
            rbndiabetesFn.Size = new Size(14, 13);
            rbndiabetesFn.TabIndex = 2;
            rbndiabetesFn.TabStop = true;
            rbndiabetesFn.UseVisualStyleBackColor = true;
            // 
            // rbndiabetesFs
            // 
            rbndiabetesFs.AutoSize = true;
            rbndiabetesFs.Location = new Point(49, 17);
            rbndiabetesFs.Name = "rbndiabetesFs";
            rbndiabetesFs.Size = new Size(14, 13);
            rbndiabetesFs.TabIndex = 18;
            rbndiabetesFs.TabStop = true;
            rbndiabetesFs.UseVisualStyleBackColor = true;
            // 
            // gbHipertensiónf
            // 
            gbHipertensiónf.Controls.Add(rbnhipertensionFn);
            gbHipertensiónf.Controls.Add(rbnHipertensionFs);
            gbHipertensiónf.Location = new Point(20, 119);
            gbHipertensiónf.Name = "gbHipertensiónf";
            gbHipertensiónf.Size = new Size(69, 36);
            gbHipertensiónf.TabIndex = 41;
            gbHipertensiónf.TabStop = false;
            // 
            // rbnhipertensionFn
            // 
            rbnhipertensionFn.AutoSize = true;
            rbnhipertensionFn.Location = new Point(6, 17);
            rbnhipertensionFn.Name = "rbnhipertensionFn";
            rbnhipertensionFn.Size = new Size(14, 13);
            rbnhipertensionFn.TabIndex = 2;
            rbnhipertensionFn.TabStop = true;
            rbnhipertensionFn.UseVisualStyleBackColor = true;
            // 
            // rbnHipertensionFs
            // 
            rbnHipertensionFs.AutoSize = true;
            rbnHipertensionFs.Location = new Point(49, 17);
            rbnHipertensionFs.Name = "rbnHipertensionFs";
            rbnHipertensionFs.Size = new Size(14, 13);
            rbnHipertensionFs.TabIndex = 18;
            rbnHipertensionFs.TabStop = true;
            rbnHipertensionFs.UseVisualStyleBackColor = true;
            // 
            // lblfamiliaresN
            // 
            lblfamiliaresN.AutoSize = true;
            lblfamiliaresN.Location = new Point(26, 19);
            lblfamiliaresN.Name = "lblfamiliaresN";
            lblfamiliaresN.Size = new Size(23, 14);
            lblfamiliaresN.TabIndex = 48;
            lblfamiliaresN.Text = "No";
            // 
            // lblfamiliaresS
            // 
            lblfamiliaresS.AutoSize = true;
            lblfamiliaresS.Location = new Point(67, 19);
            lblfamiliaresS.Name = "lblfamiliaresS";
            lblfamiliaresS.Size = new Size(18, 14);
            lblfamiliaresS.TabIndex = 47;
            lblfamiliaresS.Text = "Si";
            // 
            // gbpersonales
            // 
            gbpersonales.Controls.Add(gbDiabetesp);
            gbpersonales.Controls.Add(gbVIH);
            gbpersonales.Controls.Add(gbViolencia);
            gbpersonales.Controls.Add(gbNefropatía);
            gbpersonales.Controls.Add(gbCirugíaG);
            gbpersonales.Controls.Add(gbInfertilidad);
            gbpersonales.Controls.Add(gbCardiopatía);
            gbpersonales.Controls.Add(lblpersonalesN2);
            gbpersonales.Controls.Add(lblpersonalesS2);
            gbpersonales.Controls.Add(gbOtraCondp);
            gbpersonales.Controls.Add(lblVIH);
            gbpersonales.Controls.Add(gbEclampsiap);
            gbpersonales.Controls.Add(lblViolencia);
            gbpersonales.Controls.Add(gbPreeclampsiap);
            gbpersonales.Controls.Add(lblNefropatía);
            gbpersonales.Controls.Add(gbTBCp);
            gbpersonales.Controls.Add(lblCardipatía);
            gbpersonales.Controls.Add(gbHipertensiónp);
            gbpersonales.Controls.Add(lblInfertilidad);
            gbpersonales.Controls.Add(lblpersonalesN1);
            gbpersonales.Controls.Add(lblCirugíag);
            gbpersonales.Controls.Add(lblpersonalesS1);
            gbpersonales.Location = new Point(305, 22);
            gbpersonales.Name = "gbpersonales";
            gbpersonales.Size = new Size(587, 294);
            gbpersonales.TabIndex = 5;
            gbpersonales.TabStop = false;
            gbpersonales.Text = "PERSONALES                                                                                                                           OBSTERTICOS";
            // 
            // gbDiabetesp
            // 
            gbDiabetesp.Controls.Add(rbnDiabetesPn);
            gbDiabetesp.Controls.Add(rbnDiabetesP1);
            gbDiabetesp.Controls.Add(rbnDiabetesP2);
            gbDiabetesp.Controls.Add(rbnDiabetesP3);
            gbDiabetesp.Location = new Point(11, 79);
            gbDiabetesp.Name = "gbDiabetesp";
            gbDiabetesp.Size = new Size(156, 36);
            gbDiabetesp.TabIndex = 28;
            gbDiabetesp.TabStop = false;
            // 
            // rbnDiabetesPn
            // 
            rbnDiabetesPn.AutoSize = true;
            rbnDiabetesPn.Location = new Point(6, 17);
            rbnDiabetesPn.Name = "rbnDiabetesPn";
            rbnDiabetesPn.Size = new Size(14, 13);
            rbnDiabetesPn.TabIndex = 2;
            rbnDiabetesPn.TabStop = true;
            rbnDiabetesPn.UseVisualStyleBackColor = true;
            // 
            // rbnDiabetesP1
            // 
            rbnDiabetesP1.AutoSize = true;
            rbnDiabetesP1.Location = new Point(49, 13);
            rbnDiabetesP1.Name = "rbnDiabetesP1";
            rbnDiabetesP1.Size = new Size(29, 18);
            rbnDiabetesP1.TabIndex = 18;
            rbnDiabetesP1.TabStop = true;
            rbnDiabetesP1.Text = "I";
            rbnDiabetesP1.UseVisualStyleBackColor = true;
            // 
            // rbnDiabetesP2
            // 
            rbnDiabetesP2.AutoSize = true;
            rbnDiabetesP2.Location = new Point(83, 13);
            rbnDiabetesP2.Name = "rbnDiabetesP2";
            rbnDiabetesP2.Size = new Size(33, 18);
            rbnDiabetesP2.TabIndex = 54;
            rbnDiabetesP2.TabStop = true;
            rbnDiabetesP2.Text = "II";
            rbnDiabetesP2.UseVisualStyleBackColor = true;
            // 
            // rbnDiabetesP3
            // 
            rbnDiabetesP3.AutoSize = true;
            rbnDiabetesP3.Location = new Point(117, 13);
            rbnDiabetesP3.Name = "rbnDiabetesP3";
            rbnDiabetesP3.Size = new Size(35, 18);
            rbnDiabetesP3.TabIndex = 53;
            rbnDiabetesP3.TabStop = true;
            rbnDiabetesP3.Text = "G";
            rbnDiabetesP3.UseVisualStyleBackColor = true;
            // 
            // gbVIH
            // 
            gbVIH.Controls.Add(rbnVIHN);
            gbVIH.Controls.Add(rbnVIHS);
            gbVIH.Location = new Point(471, 245);
            gbVIH.Name = "gbVIH";
            gbVIH.Size = new Size(69, 36);
            gbVIH.TabIndex = 51;
            gbVIH.TabStop = false;
            // 
            // rbnVIHN
            // 
            rbnVIHN.AutoSize = true;
            rbnVIHN.Location = new Point(6, 17);
            rbnVIHN.Name = "rbnVIHN";
            rbnVIHN.Size = new Size(14, 13);
            rbnVIHN.TabIndex = 2;
            rbnVIHN.TabStop = true;
            rbnVIHN.UseVisualStyleBackColor = true;
            // 
            // rbnVIHS
            // 
            rbnVIHS.AutoSize = true;
            rbnVIHS.Location = new Point(49, 17);
            rbnVIHS.Name = "rbnVIHS";
            rbnVIHS.Size = new Size(14, 13);
            rbnVIHS.TabIndex = 18;
            rbnVIHS.TabStop = true;
            rbnVIHS.UseVisualStyleBackColor = true;
            // 
            // gbViolencia
            // 
            gbViolencia.Controls.Add(rbnViolenciaN);
            gbViolencia.Controls.Add(rbnViolenciaS);
            gbViolencia.Location = new Point(471, 203);
            gbViolencia.Name = "gbViolencia";
            gbViolencia.Size = new Size(69, 36);
            gbViolencia.TabIndex = 52;
            gbViolencia.TabStop = false;
            // 
            // rbnViolenciaN
            // 
            rbnViolenciaN.AutoSize = true;
            rbnViolenciaN.Location = new Point(6, 17);
            rbnViolenciaN.Name = "rbnViolenciaN";
            rbnViolenciaN.Size = new Size(14, 13);
            rbnViolenciaN.TabIndex = 2;
            rbnViolenciaN.TabStop = true;
            rbnViolenciaN.UseVisualStyleBackColor = true;
            // 
            // rbnViolenciaS
            // 
            rbnViolenciaS.AutoSize = true;
            rbnViolenciaS.Location = new Point(49, 17);
            rbnViolenciaS.Name = "rbnViolenciaS";
            rbnViolenciaS.Size = new Size(14, 13);
            rbnViolenciaS.TabIndex = 18;
            rbnViolenciaS.TabStop = true;
            rbnViolenciaS.UseVisualStyleBackColor = true;
            // 
            // gbNefropatía
            // 
            gbNefropatía.Controls.Add(rbnNefropatíaN);
            gbNefropatía.Controls.Add(rbnNefropatíaS);
            gbNefropatía.Location = new Point(471, 161);
            gbNefropatía.Name = "gbNefropatía";
            gbNefropatía.Size = new Size(69, 36);
            gbNefropatía.TabIndex = 53;
            gbNefropatía.TabStop = false;
            // 
            // rbnNefropatíaN
            // 
            rbnNefropatíaN.AutoSize = true;
            rbnNefropatíaN.Location = new Point(6, 17);
            rbnNefropatíaN.Name = "rbnNefropatíaN";
            rbnNefropatíaN.Size = new Size(14, 13);
            rbnNefropatíaN.TabIndex = 2;
            rbnNefropatíaN.TabStop = true;
            rbnNefropatíaN.UseVisualStyleBackColor = true;
            // 
            // rbnNefropatíaS
            // 
            rbnNefropatíaS.AutoSize = true;
            rbnNefropatíaS.Location = new Point(49, 17);
            rbnNefropatíaS.Name = "rbnNefropatíaS";
            rbnNefropatíaS.Size = new Size(14, 13);
            rbnNefropatíaS.TabIndex = 18;
            rbnNefropatíaS.TabStop = true;
            rbnNefropatíaS.UseVisualStyleBackColor = true;
            // 
            // gbCirugíaG
            // 
            gbCirugíaG.Controls.Add(rbnCirugiagN);
            gbCirugíaG.Controls.Add(rbnCirugíagS);
            gbCirugíaG.Location = new Point(471, 37);
            gbCirugíaG.Name = "gbCirugíaG";
            gbCirugíaG.Size = new Size(69, 36);
            gbCirugíaG.TabIndex = 50;
            gbCirugíaG.TabStop = false;
            // 
            // rbnCirugiagN
            // 
            rbnCirugiagN.AutoSize = true;
            rbnCirugiagN.Location = new Point(6, 17);
            rbnCirugiagN.Name = "rbnCirugiagN";
            rbnCirugiagN.Size = new Size(14, 13);
            rbnCirugiagN.TabIndex = 2;
            rbnCirugiagN.TabStop = true;
            rbnCirugiagN.UseVisualStyleBackColor = true;
            // 
            // rbnCirugíagS
            // 
            rbnCirugíagS.AutoSize = true;
            rbnCirugíagS.Location = new Point(49, 17);
            rbnCirugíagS.Name = "rbnCirugíagS";
            rbnCirugíagS.Size = new Size(14, 13);
            rbnCirugíagS.TabIndex = 18;
            rbnCirugíagS.TabStop = true;
            rbnCirugíagS.UseVisualStyleBackColor = true;
            // 
            // gbInfertilidad
            // 
            gbInfertilidad.Controls.Add(rbnInfertilidadN);
            gbInfertilidad.Controls.Add(rbnInfertilidadS);
            gbInfertilidad.Location = new Point(471, 79);
            gbInfertilidad.Name = "gbInfertilidad";
            gbInfertilidad.Size = new Size(69, 36);
            gbInfertilidad.TabIndex = 54;
            gbInfertilidad.TabStop = false;
            // 
            // rbnInfertilidadN
            // 
            rbnInfertilidadN.AutoSize = true;
            rbnInfertilidadN.Location = new Point(6, 17);
            rbnInfertilidadN.Name = "rbnInfertilidadN";
            rbnInfertilidadN.Size = new Size(14, 13);
            rbnInfertilidadN.TabIndex = 2;
            rbnInfertilidadN.TabStop = true;
            rbnInfertilidadN.UseVisualStyleBackColor = true;
            // 
            // rbnInfertilidadS
            // 
            rbnInfertilidadS.AutoSize = true;
            rbnInfertilidadS.Location = new Point(49, 17);
            rbnInfertilidadS.Name = "rbnInfertilidadS";
            rbnInfertilidadS.Size = new Size(14, 13);
            rbnInfertilidadS.TabIndex = 18;
            rbnInfertilidadS.TabStop = true;
            rbnInfertilidadS.UseVisualStyleBackColor = true;
            // 
            // gbCardiopatía
            // 
            gbCardiopatía.Controls.Add(rbnCardiopatíaN);
            gbCardiopatía.Controls.Add(rbnCardipatíaS);
            gbCardiopatía.Location = new Point(471, 119);
            gbCardiopatía.Name = "gbCardiopatía";
            gbCardiopatía.Size = new Size(69, 36);
            gbCardiopatía.TabIndex = 49;
            gbCardiopatía.TabStop = false;
            // 
            // rbnCardiopatíaN
            // 
            rbnCardiopatíaN.AutoSize = true;
            rbnCardiopatíaN.Location = new Point(6, 17);
            rbnCardiopatíaN.Name = "rbnCardiopatíaN";
            rbnCardiopatíaN.Size = new Size(14, 13);
            rbnCardiopatíaN.TabIndex = 2;
            rbnCardiopatíaN.TabStop = true;
            rbnCardiopatíaN.UseVisualStyleBackColor = true;
            // 
            // rbnCardipatíaS
            // 
            rbnCardipatíaS.AutoSize = true;
            rbnCardipatíaS.Location = new Point(49, 17);
            rbnCardipatíaS.Name = "rbnCardipatíaS";
            rbnCardipatíaS.Size = new Size(14, 13);
            rbnCardipatíaS.TabIndex = 18;
            rbnCardipatíaS.TabStop = true;
            rbnCardipatíaS.UseVisualStyleBackColor = true;
            // 
            // lblpersonalesN2
            // 
            lblpersonalesN2.AutoSize = true;
            lblpersonalesN2.Location = new Point(477, 19);
            lblpersonalesN2.Name = "lblpersonalesN2";
            lblpersonalesN2.Size = new Size(23, 14);
            lblpersonalesN2.TabIndex = 56;
            lblpersonalesN2.Text = "No";
            // 
            // lblpersonalesS2
            // 
            lblpersonalesS2.AutoSize = true;
            lblpersonalesS2.Location = new Point(518, 19);
            lblpersonalesS2.Name = "lblpersonalesS2";
            lblpersonalesS2.Size = new Size(18, 14);
            lblpersonalesS2.TabIndex = 55;
            lblpersonalesS2.Text = "Si";
            // 
            // gbOtraCondp
            // 
            gbOtraCondp.Controls.Add(rbnOtraCondPn);
            gbOtraCondp.Controls.Add(rbnOtraCondPs);
            gbOtraCondp.Location = new Point(11, 245);
            gbOtraCondp.Name = "gbOtraCondp";
            gbOtraCondp.Size = new Size(69, 36);
            gbOtraCondp.TabIndex = 43;
            gbOtraCondp.TabStop = false;
            // 
            // rbnOtraCondPn
            // 
            rbnOtraCondPn.AutoSize = true;
            rbnOtraCondPn.Location = new Point(6, 17);
            rbnOtraCondPn.Name = "rbnOtraCondPn";
            rbnOtraCondPn.Size = new Size(14, 13);
            rbnOtraCondPn.TabIndex = 2;
            rbnOtraCondPn.TabStop = true;
            rbnOtraCondPn.UseVisualStyleBackColor = true;
            // 
            // rbnOtraCondPs
            // 
            rbnOtraCondPs.AutoSize = true;
            rbnOtraCondPs.Location = new Point(49, 17);
            rbnOtraCondPs.Name = "rbnOtraCondPs";
            rbnOtraCondPs.Size = new Size(14, 13);
            rbnOtraCondPs.TabIndex = 18;
            rbnOtraCondPs.TabStop = true;
            rbnOtraCondPs.UseVisualStyleBackColor = true;
            // 
            // lblVIH
            // 
            lblVIH.AutoSize = true;
            lblVIH.Location = new Point(439, 260);
            lblVIH.Name = "lblVIH";
            lblVIH.Size = new Size(28, 14);
            lblVIH.TabIndex = 47;
            lblVIH.Text = "VIH";
            // 
            // gbEclampsiap
            // 
            gbEclampsiap.Controls.Add(rbnEclampsiaPn);
            gbEclampsiap.Controls.Add(rbnEclampsiaPs);
            gbEclampsiap.Location = new Point(11, 203);
            gbEclampsiap.Name = "gbEclampsiap";
            gbEclampsiap.Size = new Size(69, 36);
            gbEclampsiap.TabIndex = 44;
            gbEclampsiap.TabStop = false;
            // 
            // rbnEclampsiaPn
            // 
            rbnEclampsiaPn.AutoSize = true;
            rbnEclampsiaPn.Location = new Point(6, 17);
            rbnEclampsiaPn.Name = "rbnEclampsiaPn";
            rbnEclampsiaPn.Size = new Size(14, 13);
            rbnEclampsiaPn.TabIndex = 2;
            rbnEclampsiaPn.TabStop = true;
            rbnEclampsiaPn.UseVisualStyleBackColor = true;
            // 
            // rbnEclampsiaPs
            // 
            rbnEclampsiaPs.AutoSize = true;
            rbnEclampsiaPs.Location = new Point(49, 17);
            rbnEclampsiaPs.Name = "rbnEclampsiaPs";
            rbnEclampsiaPs.Size = new Size(14, 13);
            rbnEclampsiaPs.TabIndex = 18;
            rbnEclampsiaPs.TabStop = true;
            rbnEclampsiaPs.UseVisualStyleBackColor = true;
            // 
            // lblViolencia
            // 
            lblViolencia.AutoSize = true;
            lblViolencia.Location = new Point(401, 218);
            lblViolencia.Name = "lblViolencia";
            lblViolencia.Size = new Size(59, 14);
            lblViolencia.TabIndex = 46;
            lblViolencia.Text = "Violencia";
            // 
            // gbPreeclampsiap
            // 
            gbPreeclampsiap.Controls.Add(rbnPreeclampsiaPn);
            gbPreeclampsiap.Controls.Add(rbnPreeclampsiaPs);
            gbPreeclampsiap.Location = new Point(11, 161);
            gbPreeclampsiap.Name = "gbPreeclampsiap";
            gbPreeclampsiap.Size = new Size(69, 36);
            gbPreeclampsiap.TabIndex = 45;
            gbPreeclampsiap.TabStop = false;
            // 
            // rbnPreeclampsiaPn
            // 
            rbnPreeclampsiaPn.AutoSize = true;
            rbnPreeclampsiaPn.Location = new Point(6, 17);
            rbnPreeclampsiaPn.Name = "rbnPreeclampsiaPn";
            rbnPreeclampsiaPn.Size = new Size(14, 13);
            rbnPreeclampsiaPn.TabIndex = 2;
            rbnPreeclampsiaPn.TabStop = true;
            rbnPreeclampsiaPn.UseVisualStyleBackColor = true;
            // 
            // rbnPreeclampsiaPs
            // 
            rbnPreeclampsiaPs.AutoSize = true;
            rbnPreeclampsiaPs.Location = new Point(49, 17);
            rbnPreeclampsiaPs.Name = "rbnPreeclampsiaPs";
            rbnPreeclampsiaPs.Size = new Size(14, 13);
            rbnPreeclampsiaPs.TabIndex = 18;
            rbnPreeclampsiaPs.TabStop = true;
            rbnPreeclampsiaPs.UseVisualStyleBackColor = true;
            // 
            // lblNefropatía
            // 
            lblNefropatía.AutoSize = true;
            lblNefropatía.Location = new Point(393, 177);
            lblNefropatía.Name = "lblNefropatía";
            lblNefropatía.Size = new Size(68, 14);
            lblNefropatía.TabIndex = 45;
            lblNefropatía.Text = "Nefropatía";
            // 
            // gbTBCp
            // 
            gbTBCp.Controls.Add(rbnTBCPn);
            gbTBCp.Controls.Add(rbnTBCPs);
            gbTBCp.Location = new Point(11, 37);
            gbTBCp.Name = "gbTBCp";
            gbTBCp.Size = new Size(69, 36);
            gbTBCp.TabIndex = 42;
            gbTBCp.TabStop = false;
            // 
            // rbnTBCPn
            // 
            rbnTBCPn.AutoSize = true;
            rbnTBCPn.Location = new Point(6, 17);
            rbnTBCPn.Name = "rbnTBCPn";
            rbnTBCPn.Size = new Size(14, 13);
            rbnTBCPn.TabIndex = 2;
            rbnTBCPn.TabStop = true;
            rbnTBCPn.UseVisualStyleBackColor = true;
            // 
            // rbnTBCPs
            // 
            rbnTBCPs.AutoSize = true;
            rbnTBCPs.Location = new Point(49, 17);
            rbnTBCPs.Name = "rbnTBCPs";
            rbnTBCPs.Size = new Size(14, 13);
            rbnTBCPs.TabIndex = 18;
            rbnTBCPs.TabStop = true;
            rbnTBCPs.UseVisualStyleBackColor = true;
            // 
            // lblCardipatía
            // 
            lblCardipatía.AutoSize = true;
            lblCardipatía.Location = new Point(387, 134);
            lblCardipatía.Name = "lblCardipatía";
            lblCardipatía.Size = new Size(75, 14);
            lblCardipatía.TabIndex = 44;
            lblCardipatía.Text = "Cardiopatía";
            // 
            // gbHipertensiónp
            // 
            gbHipertensiónp.Controls.Add(rbnHipertensiónPn);
            gbHipertensiónp.Controls.Add(rbnHipertensiónPs);
            gbHipertensiónp.Location = new Point(11, 119);
            gbHipertensiónp.Name = "gbHipertensiónp";
            gbHipertensiónp.Size = new Size(69, 36);
            gbHipertensiónp.TabIndex = 41;
            gbHipertensiónp.TabStop = false;
            // 
            // rbnHipertensiónPn
            // 
            rbnHipertensiónPn.AutoSize = true;
            rbnHipertensiónPn.Location = new Point(6, 17);
            rbnHipertensiónPn.Name = "rbnHipertensiónPn";
            rbnHipertensiónPn.Size = new Size(14, 13);
            rbnHipertensiónPn.TabIndex = 2;
            rbnHipertensiónPn.TabStop = true;
            rbnHipertensiónPn.UseVisualStyleBackColor = true;
            // 
            // rbnHipertensiónPs
            // 
            rbnHipertensiónPs.AutoSize = true;
            rbnHipertensiónPs.Location = new Point(49, 17);
            rbnHipertensiónPs.Name = "rbnHipertensiónPs";
            rbnHipertensiónPs.Size = new Size(14, 13);
            rbnHipertensiónPs.TabIndex = 18;
            rbnHipertensiónPs.TabStop = true;
            rbnHipertensiónPs.UseVisualStyleBackColor = true;
            // 
            // lblInfertilidad
            // 
            lblInfertilidad.AutoSize = true;
            lblInfertilidad.Location = new Point(391, 95);
            lblInfertilidad.Name = "lblInfertilidad";
            lblInfertilidad.Size = new Size(70, 14);
            lblInfertilidad.TabIndex = 43;
            lblInfertilidad.Text = "Infertilidad";
            // 
            // lblpersonalesN1
            // 
            lblpersonalesN1.AutoSize = true;
            lblpersonalesN1.Location = new Point(17, 19);
            lblpersonalesN1.Name = "lblpersonalesN1";
            lblpersonalesN1.Size = new Size(23, 14);
            lblpersonalesN1.TabIndex = 48;
            lblpersonalesN1.Text = "No";
            // 
            // lblCirugíag
            // 
            lblCirugíag.AutoSize = true;
            lblCirugíag.Location = new Point(318, 53);
            lblCirugíag.Name = "lblCirugíag";
            lblCirugíag.Size = new Size(139, 14);
            lblCirugíag.TabIndex = 42;
            lblCirugíag.Text = "Cirugía Genito Urinaria";
            // 
            // lblpersonalesS1
            // 
            lblpersonalesS1.AutoSize = true;
            lblpersonalesS1.Location = new Point(58, 19);
            lblpersonalesS1.Name = "lblpersonalesS1";
            lblpersonalesS1.Size = new Size(18, 14);
            lblpersonalesS1.TabIndex = 47;
            lblpersonalesS1.Text = "Si";
            // 
            // lblEclampsia
            // 
            lblEclampsia.AutoSize = true;
            lblEclampsia.Location = new Point(184, 240);
            lblEclampsia.Name = "lblEclampsia";
            lblEclampsia.Size = new Size(68, 14);
            lblEclampsia.TabIndex = 11;
            lblEclampsia.Text = "Eclampsia";
            // 
            // lblTBC
            // 
            lblTBC.AutoSize = true;
            lblTBC.Location = new Point(200, 75);
            lblTBC.Name = "lblTBC";
            lblTBC.Size = new Size(33, 14);
            lblTBC.TabIndex = 6;
            lblTBC.Text = "TBC";
            // 
            // lblPreeclampsia
            // 
            lblPreeclampsia.AutoSize = true;
            lblPreeclampsia.Location = new Point(176, 199);
            lblPreeclampsia.Name = "lblPreeclampsia";
            lblPreeclampsia.Size = new Size(87, 14);
            lblPreeclampsia.TabIndex = 10;
            lblPreeclampsia.Text = "Preeclampsia";
            // 
            // lblDiabetes
            // 
            lblDiabetes.AutoSize = true;
            lblDiabetes.Location = new Point(188, 116);
            lblDiabetes.Name = "lblDiabetes";
            lblDiabetes.Size = new Size(59, 14);
            lblDiabetes.TabIndex = 7;
            lblDiabetes.Text = "Diabetes";
            // 
            // lblOtraCond
            // 
            lblOtraCond.AutoSize = true;
            lblOtraCond.Location = new Point(144, 282);
            lblOtraCond.Name = "lblOtraCond";
            lblOtraCond.Size = new Size(155, 14);
            lblOtraCond.TabIndex = 9;
            lblOtraCond.Text = "Otra Cond. Médica Grave";
            // 
            // lblHipertensión
            // 
            lblHipertensión.AutoSize = true;
            lblHipertensión.Location = new Point(177, 156);
            lblHipertensión.Name = "lblHipertensión";
            lblHipertensión.Size = new Size(81, 14);
            lblHipertensión.TabIndex = 8;
            lblHipertensión.Text = "Hipertensión";
            // 
            // btnContnuar2
            // 
            btnContnuar2.BackColor = Color.LightSkyBlue;
            btnContnuar2.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnContnuar2.ForeColor = SystemColors.ControlLightLight;
            btnContnuar2.Location = new Point(830, 678);
            btnContnuar2.Name = "btnContnuar2";
            btnContnuar2.Size = new Size(108, 23);
            btnContnuar2.TabIndex = 28;
            btnContnuar2.Text = "CONTINUAR>>";
            btnContnuar2.UseVisualStyleBackColor = false;
            btnContnuar2.Click += btnContnuar2_Click;
            // 
            // erpNumeros
            // 
            erpNumeros.ContainerControl = this;
            // 
            // btnRmenu
            // 
            btnRmenu.BackColor = Color.LightSkyBlue;
            btnRmenu.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRmenu.ForeColor = SystemColors.ControlLightLight;
            btnRmenu.Location = new Point(420, 678);
            btnRmenu.Margin = new Padding(2);
            btnRmenu.Name = "btnRmenu";
            btnRmenu.Size = new Size(148, 23);
            btnRmenu.TabIndex = 30;
            btnRmenu.Text = "REGRESAR AL MENU";
            btnRmenu.UseVisualStyleBackColor = false;
            btnRmenu.Click += btnRmenu_Click;
            // 
            // btnSalir3
            // 
            btnSalir3.BackColor = Color.LightSkyBlue;
            btnSalir3.Font = new Font("Arial Rounded MT Bold", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSalir3.ForeColor = SystemColors.ControlLightLight;
            btnSalir3.Location = new Point(27, 678);
            btnSalir3.Margin = new Padding(2);
            btnSalir3.Name = "btnSalir3";
            btnSalir3.Size = new Size(131, 23);
            btnSalir3.TabIndex = 29;
            btnSalir3.Text = "CERRAR SESION";
            btnSalir3.UseVisualStyleBackColor = false;
            btnSalir3.Click += btnSalir3_Click;
            // 
            // erpBoton
            // 
            erpBoton.ContainerControl = this;
            // 
            // ANTECEDENTES
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            ClientSize = new Size(974, 706);
            Controls.Add(btnRmenu);
            Controls.Add(btnSalir3);
            Controls.Add(btnContnuar2);
            Controls.Add(gbantecedentesF);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "ANTECEDENTES";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ANTECEDENTES";
            gbantecedentesF.ResumeLayout(false);
            gbAntecedentesO.ResumeLayout(false);
            gbAntecedentesO.PerformLayout();
            gbVC.ResumeLayout(false);
            gbVC.PerformLayout();
            gbAbortos.ResumeLayout(false);
            gbAbortos.PerformLayout();
            gbfracasoMA.ResumeLayout(false);
            gbfracasoMA.PerformLayout();
            gbembarazoplaneado.ResumeLayout(false);
            gbembarazoplaneado.PerformLayout();
            gbEmbarazoAnterior.ResumeLayout(false);
            gbEmbarazoAnterior.PerformLayout();
            gbAntecedentesDG.ResumeLayout(false);
            gbAntecedentesDG.PerformLayout();
            gbUltimoPrevio.ResumeLayout(false);
            gbUltimoPrevio.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            gbfamiliares.ResumeLayout(false);
            gbfamiliares.PerformLayout();
            gbOtraCondf.ResumeLayout(false);
            gbOtraCondf.PerformLayout();
            gbEclampsiaf.ResumeLayout(false);
            gbEclampsiaf.PerformLayout();
            gbPreeclmpsiaf.ResumeLayout(false);
            gbPreeclmpsiaf.PerformLayout();
            gbTBCf.ResumeLayout(false);
            gbTBCf.PerformLayout();
            gbDiabtesf.ResumeLayout(false);
            gbDiabtesf.PerformLayout();
            gbHipertensiónf.ResumeLayout(false);
            gbHipertensiónf.PerformLayout();
            gbpersonales.ResumeLayout(false);
            gbpersonales.PerformLayout();
            gbDiabetesp.ResumeLayout(false);
            gbDiabetesp.PerformLayout();
            gbVIH.ResumeLayout(false);
            gbVIH.PerformLayout();
            gbViolencia.ResumeLayout(false);
            gbViolencia.PerformLayout();
            gbNefropatía.ResumeLayout(false);
            gbNefropatía.PerformLayout();
            gbCirugíaG.ResumeLayout(false);
            gbCirugíaG.PerformLayout();
            gbInfertilidad.ResumeLayout(false);
            gbInfertilidad.PerformLayout();
            gbCardiopatía.ResumeLayout(false);
            gbCardiopatía.PerformLayout();
            gbOtraCondp.ResumeLayout(false);
            gbOtraCondp.PerformLayout();
            gbEclampsiap.ResumeLayout(false);
            gbEclampsiap.PerformLayout();
            gbPreeclampsiap.ResumeLayout(false);
            gbPreeclampsiap.PerformLayout();
            gbTBCp.ResumeLayout(false);
            gbTBCp.PerformLayout();
            gbHipertensiónp.ResumeLayout(false);
            gbHipertensiónp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)erpNumeros).EndInit();
            ((System.ComponentModel.ISupportInitialize)erpBoton).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gbantecedentesF;
        private GroupBox gbpersonales;
        private Label lblHipertensión;
        private Label lblDiabetes;
        private Label lblTBC;
        private Label lblEclampsia;
        private Label lblPreeclampsia;
        private Label lblOtraCond;
        private GroupBox gbfamiliares;
        private Label lblVIH;
        private Label lblViolencia;
        private Label lblNefropatía;
        private Label lblCardipatía;
        private Label lblInfertilidad;
        private Label lblCirugíag;
        private GroupBox groupBox4;
        private GroupBox gbAntecedentesO;
        private GroupBox gbAntecedentesDG;
        private GroupBox gbUltimoPrevio;
        private RadioButton rbnultprevnormal;
        private RadioButton rbnultprev4000g;
        private RadioButton rbnultprev2500g;
        private RadioButton rbnultprevnc;
        private RadioButton rbnAntecedentesDGn;
        private RadioButton rbnAntecedentesDGs;
        private Label lblVaginales;
        private TextBox txtabortos;
        private Label lblabortos;
        private TextBox txtetopico;
        private Label lblEmbaÉtopico;
        private TextBox txtgestas;
        private Label lblGestasPrevios;
        private Label lblMuertos1SEM;
        private TextBox txtviven;
        private Label lblVive;
        private TextBox txtnacidosmuertos;
        private Label lblNacidosMuertos;
        private TextBox txtnvivos;
        private Label lblNacidosVivos;
        private TextBox txtcesareas;
        private Label lblCesáreas;
        private TextBox txtpartos;
        private Label lblPartos;
        private TextBox txtvaginales;
        private TextBox txtmuertos;
        private GroupBox gbEmbarazoAnterior;
        private RadioButton rbnMenos1A;
        private DateTimePicker dateTimePicker1;
        private GroupBox gbfracasoMA;
        private RadioButton rbnfracasoMAe;
        private RadioButton rbnfracasoMAdiu;
        private RadioButton rbnfracasoMAn;
        private GroupBox gbembarazoplaneado;
        private RadioButton rbnembplaneN;
        private RadioButton rbnembplaneS;
        private RadioButton rbnfracasoMAb;
        private RadioButton rbnfracasoMAh;
        private RadioButton rbnfracasoMAna;
        private Button btnContnuar2;
        private GroupBox gbOtraCondf;
        private RadioButton rbnOtraCondFn;
        private RadioButton rbnOtraCondFs;
        private GroupBox gbEclampsiaf;
        private RadioButton rbnEclampsiaFn;
        private RadioButton rbnEclampsiaFs;
        private GroupBox gbPreeclmpsiaf;
        private RadioButton rbnpreeclampsiaFn;
        private RadioButton rbnPreeclampsiaFs;
        private GroupBox gbTBCf;
        private RadioButton rbnTBCFn;
        private RadioButton rbnTBCFs;
        private GroupBox gbDiabtesf;
        private RadioButton rbndiabetesFn;
        private RadioButton rbndiabetesFs;
        private GroupBox gbHipertensiónf;
        private RadioButton rbnhipertensionFn;
        private RadioButton rbnHipertensionFs;
        private Label lblfamiliaresN;
        private Label lblfamiliaresS;
        private GroupBox gbVIH;
        private RadioButton rbnVIHN;
        private RadioButton rbnVIHS;
        private GroupBox gbViolencia;
        private RadioButton rbnViolenciaN;
        private RadioButton rbnViolenciaS;
        private GroupBox gbNefropatía;
        private RadioButton rbnNefropatíaN;
        private RadioButton rbnNefropatíaS;
        private GroupBox gbCirugíaG;
        private RadioButton rbnCirugiagN;
        private RadioButton rbnCirugíagS;
        private GroupBox gbInfertilidad;
        private RadioButton rbnInfertilidadN;
        private RadioButton rbnInfertilidadS;
        private GroupBox gbCardiopatía;
        private RadioButton rbnCardiopatíaN;
        private RadioButton rbnCardipatíaS;
        private Label lblpersonalesN2;
        private Label lblpersonalesS2;
        private GroupBox gbOtraCondp;
        private RadioButton rbnOtraCondPn;
        private RadioButton rbnOtraCondPs;
        private GroupBox gbEclampsiap;
        private RadioButton rbnEclampsiaPn;
        private RadioButton rbnEclampsiaPs;
        private GroupBox gbPreeclampsiap;
        private RadioButton rbnPreeclampsiaPn;
        private RadioButton rbnPreeclampsiaPs;
        private GroupBox gbTBCp;
        private RadioButton rbnTBCPn;
        private RadioButton rbnTBCPs;
        private GroupBox gbHipertensiónp;
        private RadioButton rbnHipertensiónPn;
        private RadioButton rbnHipertensiónPs;
        private Label lblpersonalesN1;
        private Label lblpersonalesS1;
        private GroupBox gbDiabetesp;
        private RadioButton rbnDiabetesPn;
        private RadioButton rbnDiabetesP1;
        private RadioButton rbnDiabetesP2;
        private RadioButton rbnDiabetesP3;
        private GroupBox gbAbortos;
        private RadioButton rbn3ExpontConse;
        private ErrorProvider erpNumeros;
        private Button btnRmenu;
        private Button btnSalir3;
        private ErrorProvider erpBoton;
        private GroupBox gbVC;
        private Label lblMetodoA;
        private Label lblEmbarazoP;
    }
}