﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SISTEMA_INFORMATICO_PERINATAL
{
    public partial class ANTECEDENTES : Form
    {
        public ANTECEDENTES()
        {
            InitializeComponent();
        }

        private void btnContnuar2_Click(object sender, EventArgs e)
        {
            bool radioButtonChecked = true;

            // Limpiar cualquier mensaje de error previo
            erpBoton.Clear();

            // Validar cada grupo de RadioButtons y establecer mensajes de error si no están seleccionados
            if (!(rbnTBCFn.Checked || rbnTBCFs.Checked))
            {
                erpBoton.SetError(gbTBCf, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbndiabetesFn.Checked || rbndiabetesFs.Checked))
            {
                erpBoton.SetError(gbDiabtesf, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnhipertensionFn.Checked || rbnHipertensionFs.Checked))
            {
                erpBoton.SetError(gbHipertensiónf, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnpreeclampsiaFn.Checked || rbnPreeclampsiaFs.Checked))
            {
                erpBoton.SetError(gbPreeclmpsiaf, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnEclampsiaFn.Checked || rbnEclampsiaFs.Checked))
            {
                erpBoton.SetError(gbEclampsiaf, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnOtraCondFn.Checked || rbnOtraCondFs.Checked))
            {
                erpBoton.SetError(gbOtraCondf, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnTBCPn.Checked || rbnTBCPs.Checked))
            {
                erpBoton.SetError(gbTBCp, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnDiabetesPn.Checked || rbnDiabetesP1.Checked || rbnDiabetesP2.Checked || rbnDiabetesP3.Checked))
            {
                erpBoton.SetError(gbDiabetesp, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnHipertensiónPn.Checked || rbnHipertensiónPs.Checked))
            {
                erpBoton.SetError(gbHipertensiónp, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnPreeclampsiaPn.Checked || rbnPreeclampsiaPs.Checked))
            {
                erpBoton.SetError(gbPreeclampsiap, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnOtraCondPn.Checked || rbnOtraCondPs.Checked))
            {
                erpBoton.SetError(gbOtraCondp, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnEclampsiaPn.Checked || rbnEclampsiaPs.Checked))
            {
                erpBoton.SetError(gbEclampsiap, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnCirugiagN.Checked || rbnCirugíagS.Checked))
            {
                erpBoton.SetError(gbCirugíaG, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnInfertilidadN.Checked || rbnInfertilidadS.Checked))
            {
                erpBoton.SetError(gbInfertilidad, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnCardiopatíaN.Checked || rbnCardipatíaS.Checked))
            {
                erpBoton.SetError(gbCardiopatía, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnNefropatíaN.Checked || rbnNefropatíaS.Checked))
            {
                erpBoton.SetError(gbNefropatía, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnViolenciaN.Checked || rbnViolenciaS.Checked))
            {
                erpBoton.SetError(gbViolencia, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnVIHN.Checked || rbnVIHS.Checked))
            {
                erpBoton.SetError(gbVIH, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnDiabetesPn.Checked || rbnDiabetesP1.Checked || rbnDiabetesP2.Checked || rbnDiabetesP3.Checked))
            {
                erpBoton.SetError(gbDiabetesp, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnAntecedentesDGs.Checked || rbnAntecedentesDGn.Checked))
            {
                erpBoton.SetError(gbAntecedentesDG, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnultprevnc.Checked || rbnultprev2500g.Checked || rbnultprev4000g.Checked || rbnultprevnormal.Checked))
            {
                erpBoton.SetError(gbUltimoPrevio, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnembplaneS.Checked || rbnembplaneN.Checked))
            {
                erpBoton.SetError(gbembarazoplaneado, "Seleccione una opción.");
                radioButtonChecked = false;
            }
            if (!(rbnfracasoMAn.Checked || rbnfracasoMAb.Checked || rbnfracasoMAdiu.Checked || rbnfracasoMAe.Checked || rbnfracasoMAh.Checked || rbnfracasoMAna.Checked))
            {
                erpBoton.SetError(gbfracasoMA, "Seleccione una opción.");
                radioButtonChecked = false;
            }




            bool TextBoxcheked = true;
            //validar abortos
            if (string.IsNullOrEmpty(txtabortos.Text) || !ValidarSoloNumeros(txtabortos, erpNumeros))
            {
                erpNumeros.SetError(txtabortos, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }
            // validar gestas previas
            if (string.IsNullOrEmpty(txtgestas.Text) || !ValidarSoloNumeros(txtgestas, erpNumeros))
            {
                erpNumeros.SetError(txtgestas, "debe ingresar solo numeros"); ;
                TextBoxcheked = false;

            }
            // validar embarazo etopico
            if (string.IsNullOrEmpty(txtetopico.Text) || !ValidarSoloNumeros(txtetopico, erpNumeros))
            {
                erpNumeros.SetError(txtetopico, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }
            // validar partos
            if (string.IsNullOrEmpty(txtpartos.Text) || !ValidarSoloNumeros(txtpartos, erpNumeros))
            {
                erpNumeros.SetError(txtpartos, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }
            // validar vaginales
            if (string.IsNullOrEmpty(txtvaginales.Text) || !ValidarSoloNumeros(txtvaginales, erpNumeros))
            {
                erpNumeros.SetError(txtvaginales, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }
            //validar cesareas
            if (string.IsNullOrEmpty(txtcesareas.Text) || !ValidarSoloNumeros(txtcesareas, erpNumeros))
            {
                erpNumeros.SetError(txtcesareas, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }
            //validar nacidos vivos 
            if (string.IsNullOrEmpty(txtnvivos.Text) || !ValidarSoloNumeros(txtnvivos, erpNumeros))
            {
                erpNumeros.SetError(txtnvivos, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }
            //validar muertos 1sem
            if (string.IsNullOrEmpty(txtmuertos.Text) || !ValidarSoloNumeros(txtmuertos, erpNumeros))
            {
                erpNumeros.SetError(txtmuertos, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }
            //validar nacidos muertos
            if (string.IsNullOrEmpty(txtnacidosmuertos.Text) || !ValidarSoloNumeros(txtnacidosmuertos, erpNumeros))
            {
                erpNumeros.SetError(txtnacidosmuertos, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }

            //validar viven 
            if (string.IsNullOrEmpty(txtviven.Text) || !ValidarSoloNumeros(txtviven, erpNumeros))
            {
                erpNumeros.SetError(txtviven, "debe ingresar solo numeros");
                TextBoxcheked = false;

            }

            // Mostrar mensaje de advertencia si algún grupo no está seleccionado
            if (!radioButtonChecked || !TextBoxcheked)
            {
                MessageBox.Show("Corrija los errores antes de continuar, y verifique que todos los campos esten diligenciados");
                return;
            }



            ENFERMEDADES ven4 = new ENFERMEDADES();
            ven4.Show();
            this.Hide();
        }
        //funcion para validadr en interacciones
        private bool ValidarSoloNumeros(TextBox textBox, ErrorProvider errorProvider)
        {
            foreach (char caracter in textBox.Text)
            {
                if (!char.IsDigit(caracter) && caracter != ',')
                {
                    errorProvider.SetError(textBox, "No se admiten letras");
                    return false;
                }
            }

            errorProvider.Clear();
            return true;
        }
        private void txtabortos_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtabortos, erpNumeros);
        }

        private void txtgestas_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtgestas, erpNumeros);
        }

        private void txtetopico_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtetopico, erpNumeros);
        }

        private void txtpartos_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtpartos, erpNumeros);
        }

        private void txtvaginales_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtvaginales, erpNumeros);
        }

        private void txtcesareas_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtcesareas, erpNumeros);
        }

        private void txtnvivos_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtnvivos, erpNumeros);
        }

        private void txtmuertos_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtmuertos, erpNumeros);
        }

        private void txtnacidosmuertos_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtnacidosmuertos, erpNumeros);
        }

        private void txtviven_TextChanged(object sender, EventArgs e)
        {
            ValidarSoloNumeros(txtviven, erpNumeros);
        }



        private void btnSalir3_Click(object sender, EventArgs e)
        {
            REGISTRO ven1 = new REGISTRO();
            ven1.Show();
            this.Hide();
            MessageBox.Show("Su sesion ha sido cerrada exitosamente");
        }

        private void btnRmenu_Click(object sender, EventArgs e)
        {
            MENU ven2 = new MENU();
            ven2.Show();
            this.Hide();
        }


    }
}
